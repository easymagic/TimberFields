<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin,
        @plugins/client/ClientCustomFrontEndPlugin);
*/
class Customer{
  

  function Init(){
  	global $CustomerLogOut_Redirect;
  	global $CustomerChangeAccountPassword_Action_Redirect;

  	InstallPlugin($this->ClientFrontEndPlugin);
  	InstallTheme('@themes/ClientFrontendFramework');
  	InstallPlugin($this->ClientCustomFrontEndPlugin);

  	$CustomerLogOut_Redirect = 'AuthCustomer/LogIn';
  	$CustomerChangeAccountPassword_Action_Redirect = 'Customer/UpdateAccountProfile';
  }

  
  function UpdateAccountProfile_CustomClientContent(){}



  function Page_Init(){
  	global $redirect;
  	global $session;
  	global $data;

  	if (!isset($session['customer_session'])){
      $redirect = 'AuthCustomer/LogIn'; 
      $data['error'] = true;
      $data['message'] = 'Session expired, Please login!';
  	}
  }

  








}