<?php 
/**
@Inject(@plugins/client/ClientFrontEndPlugin,
        @templates/home/sideBarTemplate);
*/
class Home{

   
   function Init(){

   	 InstallPlugin($this->ClientFrontEndPlugin);
   	 InstallTheme('@themes/ClientFrontendFramework');
   }

   function Index_Client_Header(){
    global $hideSlider;   	
    global $smartLink;
    $smartLink = '';
    $hideSlider = false;
   }

   function StudentLogin(){
    global $session;
    global $redirect;
    if (isset($session['student_session'])){
       $redirect = 'Home/StudentProfile';
    }
   }

   function StudentProfile(){
   
   	// global $data;
   	// $data['sidebar'] = $this->sideBarTemplate->View();

   }

   function StudentChangePassword(){

   	// global $data;
   	// $data['sidebar'] = $this->sideBarTemplate->View();


   }

   function Ground_Zero(){
   	global $data;
   	$data['sidebar'] = $this->sideBarTemplate->View();   	
   }

   function StudentTests(){
   	// global $data;
   	// $data['sidebar'] = $this->sideBarTemplate->View();
   }

   function StudentTestDetail($id=''){

   }

   function StudentAssignments(){}

   function StudentAssignmentDetail($id=''){}

   function StudentLogOut(){
   	global $session;
   	global $data;
   	global $redirect;

   	unset($session['student_session']);
   	$data['message'] = 'You just logged out :(';
   	$data['error'] = false;
   	$redirect = 'Home/StudentLogin';
   }



   function Index(){
   	// echo 'Index loaded ... ';
   	// global $buffer;

   	// $buffer = 'Under development ....';
   }   

   function Play_Virtual(){
   	// global $buffer;
   	// global $model;
   	// // $model = array('@models/Test/TestGetList','GetList');
   	// $buffer.= 'Init from virtual.'; 
   }

   function Play_Action_Virtual(){
   	// global $model;
    // $model = array('@models/Test/TestCreate_Action','Create_Action');   	
   }

   
   function Play(){
   	// global $buffer;
   	// global $data;
   	// global $template;
   	// global $currentTerm;
   	// global $classes;
   	// // $data['currentTerm'] = $currentTerm;
   	// echo $currentTerm;
   	// print_r($classes);
   	// $template = '@templates/test/ply';
   }



}