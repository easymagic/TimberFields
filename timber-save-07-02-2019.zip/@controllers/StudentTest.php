<?php 
/**
@Inject(@plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class StudentTest{
  

  function Ground_Zero(){

    // global $SubjectCreate_Action_Redirect;
    // global $SubjectUpdate_Action_Redirect;
    
    global $term;
    global $class;
    
    // global $StudentChangePassword_Action_Redirect;
    
    InstallTheme('@themes/AdminBackEndFramework');

    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

  }


}