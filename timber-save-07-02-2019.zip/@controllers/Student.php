<?php 
/**
@Inject(@plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class Student{
  

  function Init(){

    global $StudentRegister_Action_Redirect;
    global $StudentUpdate_Action_Redirect;
    global $StudentChangePassword_Action_Redirect;
    
    InstallTheme('@themes/AdminBackEndFramework');

    $StudentRegister_Action_Redirect = 'Student/Read';
    $StudentUpdate_Action_Redirect = 'Student/Read';
    $StudentChangePassword_Action_Redirect = 'Student/Read';

    // InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

  }


}