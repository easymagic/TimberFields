<?php 
/**
@Inject(@plugins/apis/SiteSettingsPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class SiteSettings{
  

  function Init(){
  	global $me;
    global $SiteSettingsUpdateOption_Action_Redirect;
  	

  	$me = 'Company';
    $SiteSettingsUpdateOption_Action_Redirect = 'SiteSettings/GetOptions';
    
    InstallTheme('@themes/AdminBackEndFramework');

    InstallPlugin($this->SiteSettingsPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

    

  }


  function test(){
    
  }

  // function Page_Init(){
  // 	global $postData;
  //   $postData['role'] = 'company'; //set this by default from the server-side for security reasons.
  // }

  // function Before_GetList(){
  // 	global $db_where;
  //   global $parent_id;
  // 	$this->EntityRead->SetWhere("role='company'");
  //   $this->EntityRead->SetWhere("parent_id=$parent_id");
  // }

  // function GetList_AdminContent(){
  // 	global $db_query_log;
  // 	// print_r($db_query_log);
  // }

  function GetOption_AdminContent(){}
  function UpdateOption_AdminContent(){}




}