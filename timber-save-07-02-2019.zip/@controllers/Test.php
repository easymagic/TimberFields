<?php 
/**
@Inject(@plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class Test{
  

  function Ground_Zero(){

    global $SubjectCreate_Action_Redirect;
    global $SubjectUpdate_Action_Redirect;
    
    global $term;
    global $class;
    
    // global $StudentChangePassword_Action_Redirect;
    
    InstallTheme('@themes/AdminBackEndFramework');

    // echo $term . ',' . $class;

    // $SubjectCreate_Action_Redirect = 'Subject/Read?term=' . $term . '&class=' . $class;
    // $SubjectUpdate_Action_Redirect = 'Subject/Read?term=' . $term . '&class=' . $class;

    // $StudentRegister_Action_Redirect = 'Student/Read';
    // $StudentUpdate_Action_Redirect = 'Student/Read';
    // $StudentChangePassword_Action_Redirect = 'Student/Read';

    // InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

  }


}