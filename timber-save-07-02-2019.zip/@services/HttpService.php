<?php 


class HttpService{

  
   function DispatchAPI($route){
     // $PageObject = DIContainer::GetInstance()->InjectClass('FrontController'); 
     $dt = $this->FrontController->GetDispatch($route,array('Authorization'=>'secret_key101'));
     return json_decode($dt,true);
   }  





}