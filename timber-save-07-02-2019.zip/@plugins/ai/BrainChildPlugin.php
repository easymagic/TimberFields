<?php 
/**
@Inject(@plugins/apis/SiteSettingsPlugin);
*/
class BrainChildPlugin{
   

   function Page_Init(){
   	$this->CheckSessionLogged();
   	$this->InitStartupVars();
   }


   function InitStartupVars(){
   	global $session;
   	global $can_view_staff;
   	global $can_view_company;
   	global $can_view_company_staff;
   	global $can_view_dispatchers;
   	global $can_view_dispatch_requests;
   	global $can_view_site_settings;
   	global $can_view_dispatch_dashboard;
   	global $role;
   	global $postData;
   	global $parent_id;
   	global $userID;
   	global $charging_flat_rate;

      global $can_view_users_metrics;
      global $can_view_customers_metrics;
      global $can_view_dispatchers_metrics;
      global $can_view_dispatchers_metrics;
      global $can_view_dispatcherinfo_metrics;


   	// $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');

   	$can_view_staff = false;
   	$can_view_company = false;
   	$can_view_company_staff = false;
   	$can_view_dispatchers = false;
   	$can_view_dispatch_requests = false;
   	$can_view_site_settings = false;
   	$can_view_dispatch_dashboard = false;

   	$vars = $session['user_session'];
   	$role = $vars['role'];
   	// $userID = 'UID:' . $vars['id'] . '&nbsp;';

   	

   	// if ($role == 'admin'){
    //   $can_view_company = true;
    //   $can_view_staff = true;
    //   $can_view_dispatch_requests = true;
    //   $parent_id = $vars['id'];
    //   $can_view_site_settings = true;
      
    //   $can_view_users_metrics = true;
    //   $can_view_customers_metrics = true;
    //   $can_view_dispatchers_metrics = true;
    //   $can_view_dispatcherinfo_metrics = true;

   	// }else if ($role == 'staff'){
    //   //

    //   $can_view_users_metrics = true;
    //   // $can_view_customers_metrics = true;
    //   // $can_view_dispatchers_metrics = true;
    //   // $can_view_dispatcherinfo_metrics = true;

   	//   $parent_id = $vars['parent_id'];
   	// }else if ($role == 'company'){
    //   $can_view_company_staff = true;
    //   $can_view_dispatchers = true;
    //   $can_view_dispatch_requests = true;
    //   $parent_id = $vars['id'];
    //   $can_view_dispatch_dashboard = true;

    //   $can_view_users_metrics = true;
    //   $can_view_customers_metrics = true;
    //   $can_view_dispatchers_metrics = true;
    //   $can_view_dispatcherinfo_metrics = true;

   	// }else if ($role == 'company-staff'){
    //   //
   	//   $can_view_dispatchers = true; 	
   	//   $can_view_dispatch_requests = true;
   	//   $parent_id = $vars['parent_id'];
   	//   $can_view_dispatch_dashboard = true;

    //   $can_view_users_metrics = true;
    //   // $can_view_customers_metrics = true;
    //   $can_view_dispatchers_metrics = true;
    //   $can_view_dispatcherinfo_metrics = true;

   	// }else if ($role == 'dispatcher'){
    //   $can_view_dispatch_requests = true;
    //   $parent_id = $vars['parent_id'];
    //   $can_view_dispatch_dashboard = true;

    //   // $can_view_users_metrics = true;
    //   // $can_view_customers_metrics = true;
    //   $can_view_dispatchers_metrics = true;
    //   $can_view_dispatcherinfo_metrics = true;
      
   	// }

   }


   private function CheckSessionLogged(){
   	global $session;
    global $redirect;
 
    if (!isset($session['user_session'])){
      $redirect = 'Auth/LogIn';
    } 

   }

   function Page_Destroy(){
   	global $session;
   	
   	if (isset($session['data'])){
     unset($session['data']);
   	}

   }


	
}