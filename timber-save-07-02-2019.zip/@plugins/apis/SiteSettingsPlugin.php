<?php 
/**
@Inject(@models/SiteSettings/SiteSettingsGetOption,
        @models/SiteSettings/SiteSettingsUpdateOption);
*/
class SiteSettingsPlugin{

    
    // function UpdateOption_Action($name){
    //   global $redirect;	
    //   $this->SiteSettingsUpdateOption->UpdateOption($name);
    //   $redirect = 'SiteSettings/GetOption';
    // }

  // function GetOption(){
  //  global $data;
  //  $data['charging_flat_rate'] = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');
  //  $data['service_charge'] = $this->SiteSettingsGetOption->GetOption('service_charge');

  // }

  // function UpdateOption($name=''){
  //   global $data;
  //   $data[$name] = $this->SiteSettingsGetOption->GetOption($name);
  //   $data['name'] = $name;    
  // }
  

  function UpdateOption($name){
    global $data;
    $data[$name] = $this->SiteSettingsGetOption->GetOption($name);
    $data['name'] = $name;
  }


}