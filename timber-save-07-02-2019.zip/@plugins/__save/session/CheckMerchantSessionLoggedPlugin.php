<?php 


class CheckMerchantSessionLoggedPlugin{

  function Framework_Start(){
    global $session;
    global $data;
    global $logged;
    global $session_type;
    global $merchantID;

    $logged = false;
    $session_type = 'merchant';
    
    $data['role'] = '';
    if (isset($session['merchant_session'])){
       $data['role'] = $session['merchant_session']['role'];
       $logged = true;
       $data['session_type'] = $session_type;
       $merchantID = $session['merchant_session']['id'];
    }
   
  }


  function Page_Init(){
    // echo 'Called';
    global $logged;
    global $redirect;

    if (!$logged){
      $redirect = 'Accounts/MerchantLogin';
    }
  }


    function Page_Destroy(){
      global $session;
      global $data;

      unset($session['data']);
      unset($data['message']);
      unset($data['error']);
    }



 

}