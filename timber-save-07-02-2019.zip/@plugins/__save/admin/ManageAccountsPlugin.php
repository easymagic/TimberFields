<?php 

/**

@Inject(@models/admin/AdminGetCount,
        @models/admin/AdminGetList,
        @models/merchant/MerchantGetCount,
        @models/merchant/MerchantGetList,
        @models/transaction/TransactionGetCount,
        @models/transaction/TransactionSumAmount,
        @models/transaction/filters/TransactionFilterSuccess,
        @models/admin/AdminEnable,
        @models/admin/AdminDisable,
        @models/admin/AdminCreate,
        @models/admin/AdminChangePassword,
        @models/merchant/MerchantEnable,
        @models/merchant/MerchantDisable,
        @models/merchant/MerchantUpdate,
        @models/merchant/MerchantCreate,
        @models/merchant/MerchantChangePassword);

*/


class ManageAccountsPlugin{

  

  ////dashboard///////
  // function Dashboard_AdminContent(){

  //    global $data;

  //    $data['adminCount'] = $this->AdminGetCount->GetCount();
  //    $data['merchantCount'] = $this->MerchantGetCount->GetCount();
     
  //    //filter for successful transactions.
  //    $this->TransactionFilterSuccess->FilterSuccess();
  //    $data['transactionCount'] = $this->TransactionGetCount->GetCount();
  //    $this->TransactionFilterSuccess->FilterSuccess();
  //    $data['transactionSum'] = $this->TransactionSumAmount->SumAmount();
    
  // }

  ////admin/////////////
  function ListAdmin_AdminContent(){
    $this->AdminGetList->GetList();
  }

  function admin_data_Field_Transform(){
    SetRow('email','<b><i>' . GetRow('email') . '</i></b>');
    if (GetRow('status') == 1){
      SetRow('status_format','<i>Activated</i>');
    }else{
      SetRow('status_format','<i>Deactivated</i>');
    }
  }

  function EnableAdminAccount($id){

    global $redirect;
    
    $this->AdminEnable->Enable($id);

    $redirect = 'ManageAccounts/ListAdmin';


  }

  function DisableAdminAccount($id){
    global $redirect;

     $this->AdminDisable->Disable($id);

    $redirect = 'ManageAccounts/ListAdmin';

  }

  function AddAdmin_Action(){
    global $redirect;    
    
    $this->AdminCreate->Create();

    $redirect = 'ManageAccounts/ListAdmin';    

  }

  function ChangeAdminPassword_AdminContent($id=''){
    global $db_where;
    global $data;
    $db_where = " where (id = '$id')";
    $this->AdminGetList->GetList();
    if (count($data['admin_data']) > 0){
      $data['admin_data'] = $data['admin_data'][0];
    }
  }


  function ChangeAdminPassword_Action($id=''){

    global $redirect; 
    global $data;   

    $this->AdminChangePassword->ChangePassword($id);

    if (!$data['error']){
      $redirect = 'ManageAccounts/ListAdmin';       
    }


  }

  function ChangePassword_Action(){
    
    global $adminID;
    global $redirect;
    global $data;

    $this->AdminChangePassword->ChangePassword($adminID);
    if (!$data['error']){
      $redirect = 'ManageAccounts/Dashboard';
    }
    

  }

  ////merchant//////////

  function AddMerchant_Action(){
   global $newID;
   global $postData;
   global $redirect;
   global $data;

   $this->MerchantCreate->Create();

   if (!$data['error']){
     
     if ($postData['account_type'] == 'corporate'){
       $redirect = 'ManageAccounts/EditMerchant/' . $newID;
       $data['message'] = 'Account created successfully. Update Your company Name.';
     }

   }
  }

  function EditMerchant_Action($id){
    global $redirect;
    $this->MerchantUpdate->Update($id); 
    $redirect = 'ManageAccounts/ListMerchant';
  }

  function EditMerchant($id){
    global $db_where;
    global $data;

    $db_where = " where (id = $id) ";

    $this->MerchantGetList->GetList();
    if (count($data['merchant_data']) > 0){
      $data['merchant_data'] = $data['merchant_data'][0];
      if ($data['merchant_data']['account_type'] == 'corporate'){
        if (empty($data['merchant_data']['company_name'])){
          $data['message'] = 'Please update your company name.';
        } 
      }
    }
  }


  function ListMerchant_AdminContent(){
    $this->MerchantGetList->GetList();
  }

  function DisableMerchantAccount($id){
    global $redirect; 
    $this->MerchantDisable->Disable($id);
    $redirect = 'ManageAccounts/ListMerchant';
  }

  function EnableMerchantAccount($id){
    global $redirect; 
    $this->MerchantEnable->Enable($id);
    $redirect = 'ManageAccounts/ListMerchant';
  }

  function ChangeMerchantPassword_AdminContent($id){
    global $db_where;
    global $data;
    $db_where = " where (id = $id)";
    $this->MerchantGetList->GetList(); 
    if (count($data['merchant_data']) > 0){
      $data['merchant_data'] = $data['merchant_data'][0];
    }
  }


  function ChangeMerchantPassword_Action($id){
    global $redirect;
    global $data;

    $this->MerchantChangePassword->ChangePassword($id);
    if (!$data['error']){
     $redirect = 'ManageAccounts/ListMerchant';
    }
  }

  function LogOut(){
    global $session;
    global $data;
    global $redirect;
    unset($session['admin_session']);
    $data['message'] = 'Just logged out :)';
    $redirect = 'Accounts';
  }

  // function Page_Init(){
  //   // echo 'Called';
  //   global $logged;
  //   global $redirect;

  //   if (!$logged){
  //     $redirect = 'Accounts';
  //   }
  // }
   




    // function Page_Destroy(){
    //   global $session;
    //   global $data;

    //   unset($session['data']);
    //   unset($data['message']);
    //   unset($data['error']);
    // }



}