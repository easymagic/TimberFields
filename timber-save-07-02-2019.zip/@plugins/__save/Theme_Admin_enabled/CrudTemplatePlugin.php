<?php 

/**

@Inject(@controllers/Base);

*/

class CrudTemplatePlugin{

  private $node;
  
  function SetEntity($entity=''){$this->node = $entity;}

  function GetScope(){
    return 'private';
  }


  function Index_Render(){
    // echo "string...";
     $view = InjectKey('@templates/' . $this->node . '/indexTemplate');
     return $this->Base->BackEndLayout($view->Render());
  }


  function Edit_Render(){
    // print_r($view);
    $view = InjectKey('@templates/' . $this->node . '/EditTemplate');
    return $this->Base->BackEndLayout($view->Render());
  }


  function Add_Render(){
   $view = InjectKey('@templates/' . $this->node . '/addTemplate');
   return $this->Base->BackEndLayout($view->Render());
  }


  function Remove_Render(){
    $view = InjectKey('@templates/' . $this->node . '/RemoveTemplate');
    return $this->Base->BackEndLayout($view->Render());
  }


}


