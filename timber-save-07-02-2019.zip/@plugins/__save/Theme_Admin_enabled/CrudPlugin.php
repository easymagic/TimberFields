<?php 

/**

@Inject(@usecases/entity/EntityCreate,
        @usecases/entity/EntityRead,
        @usecases/entity/EntityUpdate,
        @usecases/entity/EntityDelete,
        @services/RequestResponse,
        @services/Input,
        @services/FormTrigger,
        @services/entity/EntityCommit,
        @services/View,
        @services/HttpService);

*/


class CrudPlugin{

 private $entity = null;
  
  function SetEntity($entity=''){
    $this->entity = $entity;
  }


  function Index_Action($id=''){
    
    if (empty($id)){
      return $this->Add_Action();
    }else{
     return $this->Remove_Action($id);  
    }
    
  }


  function Index_Data($id=''){  
    $this->HttpService->DispatchAPI("Apiv2/Collection/" . $this->entity . '/All');
    // return $dt;
  }


  function Edit_Action($id=''){
    $this->HttpService->DispatchAPI("Apiv2/Collection/" . $this->entity . "/Update/$id");
  }


  function Edit_Data($id=''){
    $this->HttpService->DispatchAPI("Apiv2/Collection/" . $this->entity . "/All/$id");
    // return $record;
  }


  function Add_Action(){
     global $redirect;
      $this->HttpService->DispatchAPI("Apiv2/Collection/" . $this->entity . '/Create');
      // $redirect = 'Category/Index';
  }


  function Remove_Action($id=''){
    $this->HttpService->DispatchAPI("Apiv2/Collection/" . $this->entity . "/Delete/$id");
  }

  function Logged_Admin(){
    echo 'Checking Session ... ';
  }





}


