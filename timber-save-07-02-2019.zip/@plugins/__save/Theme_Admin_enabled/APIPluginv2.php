<?php 

/**

@Inject(@services/RequestResponse,
        @services/entity/EntityCommit,
        @services/CrudService,
        @services/AuthorizationService);

*/

class APIPluginv2{

  private $entity;
  private $plugins = array();
  

  function GetScope(){
    return 'private';
  }

  function LoadAPIPlugins(){
    $dir = scandir('api-plugins');
    $dir = array_diff($dir, array('.','..'));
    foreach ($dir as $k=>$v){
      $r = explode('.php', $v);
      require_once('api-plugins/' . $r[0] . '.php');
      $cls = $r[0];
      $this->plugins[$r[0]] = InjectKey('api-plugins/' . $r[0]);
    }
  }

  function SetEntity($entity=''){
    $this->entity = $entity;
    $this->LoadAPIPlugins();
  }


  function CallPlugins($hook,$args){
     $r = array();

     $entity = array_shift($args);
     $action = array_shift($args);
     foreach ($this->plugins as $k=>$v){

          if (method_exists($v, $action . $hook)){
            array_unshift($args,$entity);
            $r = call_user_func_array(array($v,$action . $hook), $args);
            break;
          }

     }
   return $r;
  }

  function Collection_Action(){
     global $data;

     $result = $this->CallPlugins('_Action',func_get_args());
     foreach ($result as $k=>$v){
       $data[$k] = $v;
     }

  }

  function Collection_Data(){
    
    global $data;
    $result = $this->CallPlugins('_Data',func_get_args()); 
    
     foreach ($result as $k=>$v){
       $data[$k] = $v;
     }

  }


  function Collection_Render(){
    global $dataJSON;

    return json_encode($dataJSON);
  }




}


