<?php 
/**
@Inject(@templates/frontend/Client_HeaderTemplate,
        @templates/frontend/Client_FooterTemplate);
*/
class ClientFrontEndPlugin{


  function Client_Header(){
    global $buffer;
    $buffer.=$this->Client_HeaderTemplate->View();
  }

  function Client_Footer(){
    global $buffer;
    $buffer.=$this->Client_FooterTemplate->View();
  }

  // function Page_Destroy(){
  //  	global $session;
  //  	global $data;
  //  	if (isset($session['data'])){
  //     unset($session['data']);
  //     $data = array();
  //  	}  	
  // }




}