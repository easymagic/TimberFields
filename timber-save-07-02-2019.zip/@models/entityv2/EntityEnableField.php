<?php 

/**

@Inject(@models/entityv2/EntityUpdate);

*/

class EntityEnableField{



   function EnableField($entity,$field){
     global $data;
     global $db_where;

     $data['error'] = false;

     $this->EntityUpdate->SetData(array($field=>1));

   	 $this->EntityUpdate->DoUpdate($entity);

   	 // $data['message'] = $field . ' enabled.';

   }




}