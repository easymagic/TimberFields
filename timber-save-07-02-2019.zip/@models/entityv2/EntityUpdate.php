<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class EntityUpdate{

   private $data = array();

   private $forceAction_ = false;

   function DoUpdate($entity){

   	 global $db_where;
   	 global $db_sql;
     
     if (!empty($db_where) || $this->forceAction_){
      DbUpdate($entity,$this->data);
      $this->forceAction_ = false;
     }

     // die($db_sql);
     
   }

   function ForceAction(){
     $this->forceAction_ = true;
   }

   function SetData($data){
    $this->data = $data;
   }



}