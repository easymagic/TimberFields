<?php 
/**
@Inject(@models/User/UserLogIn_Action,
        @models/Student/StudentAutoUpdateTerms);
*/
class AuthLogIn_Action{

  

    function LogIn_Action(){
      $this->UserLogIn_Action->LogIn_Action();
      $this->StudentAutoUpdateTerms->AutoUpdateTerms();
    }


}