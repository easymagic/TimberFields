<?php 

/**

@Inject(@models/entityv2/EntityDisableField);

*/

class AdminDisable{

  

   function Disable($id){
   	 global $db_sql;

   	 $this->EntityRead->SetWhere("id=$id");
     $this->EntityDisableField->DisableField('admin','status');

     echo $db_sql;
     
   }


}