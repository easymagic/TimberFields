<?php 

class TransactionFilterSuccess{

  


   function FilterSuccess(){//
   	global $db_where;
   	global $transactionFilters;

   	$transactionFilters[] = "pstatus = 'success'";
     
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") "; 

   }



}