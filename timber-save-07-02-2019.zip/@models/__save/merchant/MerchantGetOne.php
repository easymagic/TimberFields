<?php 
/**

@Inject(@models/entityv2/EntityReadOne);

*/
class MerchantGetOne{


  function GetOne($id){
  	global $data;

  	$this->EntityRead->SetWhere("id=$id");
  	$this->EntityReadOne->ReadOne('merchant');

  	return $data['merchant_data'];
  }



}