<?php 

/**

@Inject(@models/entityv2/EntityReadOne);

*/

class GWSettingsGetOne{

  function GetOne($id){
  	$this->EntityRead->SetWhere("id=$id");
  	$this->EntityReadOne->ReadOne('gw_settings');
  }

}