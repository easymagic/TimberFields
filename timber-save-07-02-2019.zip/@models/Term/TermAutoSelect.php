<?php 

class TermAutoSelect{
  
  private $months = array(
   'Jan'=>1,
   'Feb'=>2,
   'Mar'=>3,
   'Apr'=>4,
   'May'=>5,
   'Jun'=>6,
   'Jul'=>7,
   'Aug'=>8,
   'Sep'=>9,
   'Oct'=>10,
   'Nov'=>11,
   'Dec'=>12
  );


  private $terms = array('first-term','second-term','third-term','Holiday');
  

  function Init(){
  	$this->AutoSelect();
    $this->GetList();
  }

  function GetList(){
    global $terms;
    $terms = $this->terms;
    return $this->terms;
  }

  function AutoSelect(){
    global $currentTerm;

    $day = +date('d');
    $month = +date('m');
    $year = +date('y');

    if ($month >= $this->months['Sep'] && $month <= $this->months['Dec']){
     $currentTerm = $this->terms[0];
    }else if ($month >= $this->months['Jan'] && $month <= $this->months['Apr']){
     $currentTerm = $this->terms[1];
    }else if ($month >= $this->months['May'] && $month <= $this->months['Jul']){
     $currentTerm = $this->terms[2];
    }else{
     $currentTerm = $this->terms[3];  	
    }

    // echo $currentTerm;
    // echo "$day,$month,$year<br />";

  }
  

}