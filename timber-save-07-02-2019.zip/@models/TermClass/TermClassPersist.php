<?php 
/**
@Inject(@models/Class/ClassLoad,
        @models/Term/TermAutoSelect);
*/
class TermClassPersist{

  
   function Init(){
    $this->Persist();
   }


   function Persist(){
   	global $session;
   	global $post;
    global $postData;
   	global $term;
   	global $class;
    global $get;

   	$terms = $this->TermAutoSelect->GetList();
   	$classes = $this->ClassLoad->GetList();

    // print_r($terms);
    // print_r($classes);
    // echo 'Called.';

    if (isset($get['term'])){
       $session['term'] = $get['term'];
    }
    if (isset($get['class'])){
      $session['class'] = $get['class'];
    }


   	if (isset($post['term'])){
       $session['term'] = $post['term'];
   	}
   	if (isset($post['class'])){
   		$session['class'] = $post['class'];
   	}
     
     // print_r($postData);
     // print_r($_REQUEST);
     // die();

    if (isset($postData['term'])){
       $session['term'] = $postData['term'];
    }
    if (isset($postData['class'])){
      $session['class'] = $postData['class'];
    }



   	if (!isset($session['term'])){
      $session['term'] = $terms[0];
   	}
    if (!isset($session['class'])){
      $session['class'] = $classes[0];
    }

    $term = $session['term'];
    $class = $session['class'];

   }


}