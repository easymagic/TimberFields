<?php 
class StudentRead{

  
  function Read(){
  	global $db_sql;
  	$this->EntityRead->Read('student');
  	// echo $db_sql;
  }



}