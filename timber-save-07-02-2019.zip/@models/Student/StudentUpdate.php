<?php 
/**
@Inject(@models/Student/StudentReadOne);
*/

class StudentUpdate{

  
   function Update($id){
    $this->StudentReadOne->ReadOne($id);
   }


}