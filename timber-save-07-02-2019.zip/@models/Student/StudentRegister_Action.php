<?php 
/**
@Inject(@models/Entity/EntityAccountCreate,
        @models/Student/StudentUpdatePassport_Action);
*/

class StudentRegister_Action{

  
  function Register_Action(){
  	global $newID;
  	global $postData;
  	global $post;

   	$this->EntityCheckPassword->SetData($post);
   	$this->EntityAccountCreate->SetData($postData);
   	$this->EntityAccountCreate->SetDuplicateField('email');
  	$this->EntityAccountCreate->AccountCreate('student');
    
    if (!empty($newID)){
  	  $this->StudentUpdatePassport_Action->UpdatePassport_Action($newID);
    }

  } 


}