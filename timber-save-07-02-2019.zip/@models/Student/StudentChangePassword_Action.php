<?php 
class StudentChangePassword_Action{

  

   function ChangePassword_Action($id){

   	 $this->EntityRead->SetWhere("id=$id");
   	 $this->EntityChangePassword->ChangePassword('student');

   }  




}