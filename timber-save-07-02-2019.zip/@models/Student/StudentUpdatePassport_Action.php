<?php 
/**
@Inject(@models/entityv2/EntityUpdateUpload);
*/
class StudentUpdatePassport_Action{


	 function UpdatePassport_Action($id){
	   global $data;	

	   $this->EntityRead->SetWhere("id=$id");	
       $this->EntityUpdateUpload->UpdateUpload('student','passport','uploads/student/studentpassport/');

       // $data['message'] = ',Passport saved.';
	 }

}