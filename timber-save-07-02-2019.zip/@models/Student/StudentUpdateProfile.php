<?php 
/**
@Inject(@models/Student/StudentReadProfile);
*/
class StudentUpdateProfile{

  

   function UpdateProfile(){
     $this->StudentReadProfile->ReadProfile();
   }


}