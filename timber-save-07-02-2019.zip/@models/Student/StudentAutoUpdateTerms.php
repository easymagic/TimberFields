<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/
class StudentAutoUpdateTerms{
  

   function AutoUpdateTerms(){
   	global $currentTerm;
     
    $this->EntityUpdate->ForceAction();
    $this->EntityUpdate->SetData(array(
      'term'=>$currentTerm
    ));
    $this->EntityUpdate->DoUpdate('student');

   }

}