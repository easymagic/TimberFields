<?php 
/**
@Inject(@models/Student/StudentChangePassword_Action);
*/
class StudentProfileChangePassword_Action{
  

   function ProfileChangePassword_Action(){
   	global $session;
   	$id = $session['student_session']['id'];
    $this->StudentChangePassword_Action->ChangePassword_Action($id);
   }


}