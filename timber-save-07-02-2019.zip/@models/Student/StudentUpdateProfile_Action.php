<?php 
/**
@Inject(@models/Student/StudentUpdate_Action);
*/
class StudentUpdateProfile_Action{

  
  function UpdateProfile_Action(){
  	global $session;
  	$id = $session['student_session']['id'];
    $this->StudentUpdate_Action->Update_Action($id);
  } 


}