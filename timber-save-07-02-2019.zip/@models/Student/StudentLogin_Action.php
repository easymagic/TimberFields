<?php 

class StudentLogin_Action{

  

   function Login_Action(){
   	global $post;
   	$this->EntityLogin->SetData($post);
   	$this->EntityLogin->Login('student');
   }


}