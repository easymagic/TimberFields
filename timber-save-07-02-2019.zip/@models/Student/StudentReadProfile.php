<?php 
/**
@Inject(@models/Student/StudentReadOne);
*/
class StudentReadProfile{

  
  function ReadProfile(){
  	global $session;
  	$id = $session['student_session']['id'];
  	$this->StudentReadOne->ReadOne($id);
  }



}