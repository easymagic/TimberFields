<?php 
/**
@Inject(@models/Subject/SubjectReadOne);
*/
class SubjectUpdate{

  
   function Update($id){
     $this->SubjectReadOne->ReadOne($id);
   }


}