<?php 
class SubjectUpdate_Action{


     function Update_Action($id){
     	
     	global $postData;
     	global $data;

     	$this->EntityRead->SetWhere("id=$id");
     	$this->EntityUpdate->SetData($postData);
     	$this->EntityUpdate->DoUpdate('subject');

     	$data['message'] = 'Subject updated';

     }

}