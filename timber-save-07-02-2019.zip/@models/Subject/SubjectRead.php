<?php 
/**
@Inject(@models/TermClass/TermClassPersist);
*/
class SubjectRead{


     function Read(){
     	global $term;
     	global $class;

     	global $db_sql;

        $this->TermClassPersist->Persist();
        $this->EntityRead->SetWhere("term='$term' and class='$class'");
     	$this->EntityRead->Read('subject');

     	// echo $db_sql;
     	
     }

}