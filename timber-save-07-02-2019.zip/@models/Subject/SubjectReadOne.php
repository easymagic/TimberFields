<?php 

class SubjectReadOne{
  

    function ReadOne($id){
      $this->EntityRead->SetWhere("id=$id");
      $this->EntityReadOne->ReadOne('subject');
    }

}