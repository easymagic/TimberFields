<?php 
class SubjectCreate_Action{


     function Create_Action(){
     	global $postData;
     	global $data;

     	$postData['date_created'] = date('Y-m-d h:i:s');
     	
     	$this->EntityCreate->SetData($postData);
     	$this->EntityCreate->DoCreate('subject');

        $data['message'] = 'Subject Created.';
     }

}