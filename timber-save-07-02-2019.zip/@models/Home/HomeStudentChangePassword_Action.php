<?php 
/**
@Inject(@models/Student/StudentProfileChangePassword_Action);
*/
class HomeStudentChangePassword_Action{


   
   function StudentChangePassword_Action(){
     $this->StudentProfileChangePassword_Action->ProfileChangePassword_Action();
   }


}