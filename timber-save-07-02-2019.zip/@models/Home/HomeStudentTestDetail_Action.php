<?php 
/**
@Inject(@models/StudentTest/StudentTestUpdate_Action);
*/
class HomeStudentTestDetail_Action{


  
   function StudentTestDetail_Action($id){

   	 $id = base64_decode($id);

   	 $this->StudentTestUpdate_Action->Update_Action($id);

   }


}