<?php 
/**
@Inject(@models/StudentAssignment/StudentAssignmentReadOne);
*/
class HomeStudentAssignmentDetail{
  

    function StudentAssignmentDetail($id=''){

    	 $id = base64_decode($id);
       
         $this->StudentAssignmentReadOne->ReadOne($id);


    }

}