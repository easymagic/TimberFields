<?php 
/**
@Inject(@models/Student/StudentLogin_Action);
*/
class HomeStudentLogin_Action{

   
    function StudentLogin_Action(){
   
      $this->StudentLogin_Action->Login_Action();

    }

}