<?php 
/**
@Inject(@models/StudentTest/StudentTestReadOne);
*/

class HomeStudentTestDetail{
   
  

     function StudentTestDetail($id){

     	 $id = base64_decode($id);

     	 $this->StudentTestReadOne->ReadOne($id);


     }




}