<?php 
/**
@Inject(@models/StudentTest/StudentTestRead);
*/
class HomeStudentTests{

  

   function StudentTests(){
        global $session;
        $id = $session['student_session']['id'];
        $this->EntityRead->SetWhere("student_id='$id'");
        $this->StudentTestRead->Read();
        //StudentTestRead

   }



}