<?php 
/**
@Inject(@models/StudentAssignment/StudentAssignmentRead);
*/
class HomeStudentAssignments{

  

   function StudentAssignments(){
        global $session;
        $id = $session['student_session']['id'];
        $this->EntityRead->SetWhere("student_id='$id'");
        $this->StudentAssignmentRead->Read();
        // echo 'Called.';
        //StudentTestRead

   }



}