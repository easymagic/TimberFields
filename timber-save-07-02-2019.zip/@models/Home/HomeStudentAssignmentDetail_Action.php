<?php 
/**
@Inject(@models/StudentAssignment/StudentAssignmentUpdate_Action);
*/
class HomeStudentAssignmentDetail_Action{
  


    function StudentAssignmentDetail_Action($id=''){

    	 $id = base64_decode($id);

    	 $this->StudentAssignmentUpdate_Action->Update_Action($id);



    }


}