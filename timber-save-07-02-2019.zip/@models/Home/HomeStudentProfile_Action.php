<?php 
/**
@Inject(@models/Student/StudentUpdateProfile_Action);
*/
class HomeStudentProfile_Action{

   

   function StudentProfile_Action(){
     $this->StudentUpdateProfile_Action->UpdateProfile_Action();
   }



}