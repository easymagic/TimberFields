<?php 
/**
@Inject(@models/Student/StudentReadProfile);
*/
class HomeStudentProfile{

   
    function StudentProfile(){
     $this->StudentReadProfile->ReadProfile();
    }


}