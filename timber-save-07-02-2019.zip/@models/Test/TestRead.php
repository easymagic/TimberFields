<?php 
/**
@Inject(@models/Subject/SubjectReadOne);
*/
class TestRead{


    
    function Read($subject_id=''){
    	$this->SubjectReadOne->ReadOne($subject_id);
    	$this->EntityRead->SetWhere("subject_id = '$subject_id'");
    	$this->EntityRead->Read('test');
    }

}