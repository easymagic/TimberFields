<?php 

class TestUpdate_Action{
  

   function Update_Action($id){
     global $postData;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData($postData);
     $this->EntityUpdate->DoUpdate('test');

     $data['message'] = 'Test updated.';
   }


}