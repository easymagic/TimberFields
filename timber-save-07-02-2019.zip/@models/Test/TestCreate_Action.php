<?php
/**
@Inject(@models/Student/StudentRead,
        @models/StudentTest/StudentTestCreate_Action,
        @models/Test/TestReadOne);
*/
class TestCreate_Action{


     function Create_Action($subject_id){
     	global $postData;
     	global $data;     	
     	global $currentTerm;
     	global $newID;
      global $class;

      global $term;
      global $class;
      global $db_sql;


     	// $class = $postData['class'];

     	$postData['date_created'] = date('Y-m-d h:i:s');
      $postData['subject_id'] = $subject_id;
      $postData['term'] = $term;
      $postData['class'] = $class;

     	$this->EntityRead->SetWhere("term='$currentTerm'");
     	$this->EntityRead->SetWhere("class='$class'");
     	$this->StudentRead->Read();

      // echo $db_sql;

        $this->EntityCreate->SetData($postData);
        // echo 'A called.';
        $this->EntityCreate->DoCreate('test');
        $new_test_id = $newID;

        foreach ($data['student_data'] as $k=>$student){

           $this->TestReadOne->ReadOne($new_test_id);
           $postData = array();
           $postData['test_id']	= $new_test_id;
           $postData['term'] = $currentTerm;
           $postData['class'] = $class;
           $postData['student_id'] = $student['id'];
           $postData['date_created'] = date('Y-m-d h:i:s');
           $postData['correction'] = $data['test_data']['correction'];
            
           $this->StudentTestCreate_Action->Create_Action();

        }


        $data['message'] = 'Test Created and notification sent.';
        
     }

}