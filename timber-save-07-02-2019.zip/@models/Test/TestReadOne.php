<?php 
/**
@Inject(@models/Subject/SubjectReadOne);
*/
class TestReadOne{


    function ReadOne($id){
    	global $data;
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('test');

    	$this->SubjectReadOne->ReadOne($data['test_data']['subject_id']);
    }

}