<?php
/**
@Inject(@models/Student/StudentRead,
        @models/Subject/SubjectReadOne);
*/
class TestCreate{


     function Create($subject_id){
     	global $data;  
      global $db_sql;   	
      $this->SubjectReadOne->ReadOne($subject_id);
      $data['subject_id'] = $subject_id;
      // print_r($data);
      // echo $db_sql;
     }

}