<?php 

class TestGetCount{
  


  function GetCount(){
  	return $this->EntityCount->GetCount('test');
  }


}