<?php 

class AssignmentUpdate_Action{
  

   function Update_Action($id){
     global $postData;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData($postData);
     $this->EntityUpdate->DoUpdate('assignment');

     $data['message'] = 'Assignment updated.';
   }


}