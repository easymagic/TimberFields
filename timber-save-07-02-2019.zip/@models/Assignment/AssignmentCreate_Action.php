<?php
/**
@Inject(@models/Student/StudentRead,
        @models/StudentAssignment/StudentAssignmentCreate_Action,
        @models/Assignment/AssignmentReadOne);
*/
class AssignmentCreate_Action{


     function Create_Action($subject_id){
     	global $postData;
     	global $data;     	
     	global $currentTerm;
     	global $newID;
      global $class;

      global $term;
      global $class;
      global $db_sql;


     	// $class = $postData['class'];

     	$postData['date_created'] = date('Y-m-d h:i:s');
      $postData['subject_id'] = $subject_id;
      $postData['term'] = $term;
      $postData['class'] = $class;

     	$this->EntityRead->SetWhere("term='$currentTerm'");
     	$this->EntityRead->SetWhere("class='$class'");
     	$this->StudentRead->Read();

      // echo $db_sql;

        $this->EntityCreate->SetData($postData);
        // echo 'A called.';
        $this->EntityCreate->DoCreate('assignment');
        $new_assignment_id = $newID;

        foreach ($data['student_data'] as $k=>$student){

           $this->AssignmentReadOne->ReadOne($new_assignment_id);
           $postData = array();
           $postData['assignment_id']	= $new_assignment_id;
           $postData['term'] = $currentTerm;
           $postData['class'] = $class;
           $postData['student_id'] = $student['id'];
           $postData['date_created'] = date('Y-m-d h:i:s');
           $postData['correction'] = $data['assignment_data']['correction'];
            
           $this->StudentAssignmentCreate_Action->Create_Action();

           // echo $db_sql;

        }


        $data['message'] = 'Assignment Created and notification sent.';
        
     }

}