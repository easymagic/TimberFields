<?php 
/**
@Inject(@models/Subject/SubjectReadOne);
*/
class AssignmentReadOne{


    function ReadOne($id){
    	global $data;
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('assignment');

    	$this->SubjectReadOne->ReadOne($data['assignment_data']['subject_id']);
    }

}