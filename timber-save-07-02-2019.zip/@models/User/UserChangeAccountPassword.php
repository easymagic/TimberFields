<?php 
/**
@Inject(@models/User/UserChangePassword);
*/
class UserChangeAccountPassword{


	function ChangeAccountPassword(){
       global $session;
       $id = $session['user_session']['id'];
       $this->UserChangePassword->ChangePassword($id);
	}
}