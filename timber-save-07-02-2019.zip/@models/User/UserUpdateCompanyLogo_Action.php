<?php
/**
@Inject(@models/entityv2/EntityUpdateUpload);
*/

class UserUpdateCompanyLogo_Action{
  

   function UpdateCompanyLogo_Action($id){
     global $data;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdateUpload->UpdateUpload('user','company_logo','uploads/user/companylogo/');
     
     $data['message'] = 'Company logo updated successfully.';
     
   }


}