<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/


class UserGetList{


  function GetList(){
   global $db_sql;	
   global $charging_flat_rate;
   $this->EntityRead->Read('user');
   // echo $db_sql;
   // $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');
  }


}