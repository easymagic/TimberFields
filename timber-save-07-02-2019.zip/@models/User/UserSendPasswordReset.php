<?php 
/**
@Inject(@models/entityv2/EntitySendPasswordReset);
*/
class UserSendPasswordReset{

  

    function SendPasswordReset(){
      $this->EntitySendPasswordReset->SendPasswordReset('user','email');
    }


}