<?php 
/**
@Inject(@models/entityv2/EntitySendPasswordReset);
*/
class UserSendPasswordReset_Action{

  

    function SendPasswordReset_Action(){
      $this->EntitySendPasswordReset->SendPasswordReset('user','email');
    }


}