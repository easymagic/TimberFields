<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class UserFilterCompanyStaff{

   
     function FilterCompanyStaff(){
     	$this->EntityRead->SetWhere("role='company-staff'");
     }


}