<?php 
/**
@Inject(@models/entityv2/EntityChangePasswordReset);
*/


class UserChangePasswordReset{
  


    function ChangePasswordReset($id,$check){
      $this->EntityChangePasswordReset->ChangePasswordReset('user',$id,$check);
    }


}