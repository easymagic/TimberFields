<?php 
/**
@Inject(@models/StudentAssignment/StudentAssignmentReadOne);
*/
class StudentAssignmentProfileReadOne{

    
     function ProfileReadOne(){
     	global $session;
     	$id = $session['student_session']['id'];
     	$this->EntityRead->SetWhere("student_id='$id'");
        $this->StudentAssignmentReadOne->ReadOne($id);
     }

}