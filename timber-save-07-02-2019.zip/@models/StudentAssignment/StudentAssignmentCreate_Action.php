<?php 

class StudentAssignmentCreate_Action{

   
    function Create_Action(){
    	global $postData;
    	$this->EntityCreate->SetData($postData);
    	$this->EntityCreate->DoCreate('student_assignment');
    }

}