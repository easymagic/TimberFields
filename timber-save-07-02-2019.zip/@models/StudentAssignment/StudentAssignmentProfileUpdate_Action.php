<?php 
/**
@Inject(@models/StudentAssignment/StudentAssignmentUpdate_Action);
*/
class StudentAssignmentProfileUpdate_Action{
  

   function ProfileUpdate_Action($id){
    global $session;
    $student_id = $session['student_session']['id'];
    $this->EntityRead->SetWhere("student_id='$student_id");
    $this->StudentAssignmentUpdate_Action->Update_Action($id);
   }
  

}