<?php 
/**
@Inject(@models/Subject/SubjectReadOne,
        @models/Assignment/AssignmentReadOne,
        @models/Student/StudentReadOne);
*/
class StudentAssignmentRead{
  

    function Read($assignment_id=''){
    	
    	global $data;
    	// global $db_sql;

    	
    	// echo $data['test_data']['subject_id'];
    	// echo $db_sql;
    	// $this->SubjectReadOne->ReadOne($data['test_data']['subject_id']);
    	// echo $db_sql;
    	if (!empty($assignment_id)){
         $this->AssignmentReadOne->ReadOne($assignment_id);
         $this->EntityRead->SetWhere("assignment_id='$assignment_id'");
        } 

        $this->EntityRead->Read('student_assignment');

    	// echo $db_sql;

        // print_r($data);

    	foreach ($data['student_assignment_data'] as $k=>$v){

    		$this->StudentReadOne->ReadOne($v['student_id']);
    		$data['student_assignment_data'][$k]['student'] = $data['student_data'];


            $this->AssignmentReadOne->ReadOne($v['assignment_id']);
            $data['student_assignment_data'][$k]['assignment'] = $data['assignment_data'];
            
            $this->SubjectReadOne->ReadOne($data['assignment_data']['subject_id']);
            $data['student_assignment_data'][$k]['subject'] = $data['subject_data'];


    	}

    }


}