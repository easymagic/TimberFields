<?php 
/**
@Inject(@models/Assignment/AssignmentReadOne,
        @models/Student/StudentReadOne,
        @models/Subject/SubjectReadOne);
*/
class StudentAssignmentReadOne{

    function ReadOne($id){

    	global $data;

    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('student_assignment');

    	$this->AssignmentReadOne->ReadOne($data['student_assignment_data']['assignment_id']);
    	$this->SubjectReadOne->ReadOne($data['assignment_data']['subject_id']);
    	$this->StudentReadOne->ReadOne($data['student_assignment_data']['student_id']);


    }

}