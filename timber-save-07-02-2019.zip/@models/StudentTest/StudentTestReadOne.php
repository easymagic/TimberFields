<?php 
/**
@Inject(@models/Test/TestReadOne,
        @models/Student/StudentReadOne,
        @models/Subject/SubjectReadOne);
*/

class StudentTestReadOne{

    function ReadOne($id){
        global $data; 
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('student_test');
    	$this->TestReadOne->ReadOne($data['student_test_data']['test_id']);
    	$this->SubjectReadOne->ReadOne($data['test_data']['subject_id']);
    	$this->StudentReadOne->ReadOne($data['student_test_data']['student_id']);

    }

}