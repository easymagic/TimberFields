<?php 
/**
@Inject(@models/Subject/SubjectReadOne,
        @models/Test/TestReadOne,
        @models/Student/StudentReadOne,
        @models/Subject/SubjectReadOne);
*/
class StudentTestRead{
  

    function Read($test_id=''){
    	
    	global $data;
    	// global $db_sql;

    	
    	// echo $data['test_data']['subject_id'];
    	// echo $db_sql;
    	// $this->SubjectReadOne->ReadOne($data['test_data']['subject_id']);
    	// echo $db_sql;
    	
        if (!empty($test_id)){ 
         $this->TestReadOne->ReadOne($test_id);
         $this->EntityRead->SetWhere("test_id='$test_id'");
        } 

    	$this->EntityRead->Read('student_test');

    	// echo $db_sql;

    	foreach ($data['student_test_data'] as $k=>$v){

    		$this->StudentReadOne->ReadOne($v['student_id']);
    		$data['student_test_data'][$k]['student'] = $data['student_data'];
            
            $this->TestReadOne->ReadOne($v['test_id']);
            $data['student_test_data'][$k]['test'] = $data['test_data'];
            
            $this->SubjectReadOne->ReadOne($data['test_data']['subject_id']);
            $data['student_test_data'][$k]['subject'] = $data['subject_data'];

    	}

    }


}