<?php 

class StudentTestUpdate_Action{

   
    function Update_Action($id){
    	global $postData;
    	global $data;
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityUpdate->SetData($postData);
    	$this->EntityUpdate->DoUpdate('student_test');
    	$data['message'] = 'Answer submitted.';
    }

}