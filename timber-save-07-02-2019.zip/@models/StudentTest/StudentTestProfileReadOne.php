<?php 
/**
@Inject(@models/StudentTest/StudentTestReadOne);
*/
class StudentTestProfileReadOne{

    
     function ProfileReadOne(){
     	global $session;
     	$id = $session['student_session']['id'];
     	$this->EntityRead->SetWhere("student_id='$id'");
        $this->StudentTestReadOne->ReadOne($id);
     }

}