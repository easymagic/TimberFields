<?php 
/**
@Inject(@models/StudentTest/StudentTestRead);
*/
class StudentTestProfileRead{
  

   function ProfileRead(){
   	global $session;
   	global $currentTerm;

   	$id = $session['student_session']['id'];
   	$class = $session['student_session']['class'];

   	$this->EntityRead->SetWhere("term = '$currentTerm' and class='$class'");

   	$this->StudentTestRead->Read();

   }

   

}