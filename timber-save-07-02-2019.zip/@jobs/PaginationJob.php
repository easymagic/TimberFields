<?php 

/**

@Inject(app-x/core/EmailQueue);

*/

$page = '';
$rpp = '';
if (isset($_GET['rpp']) && is_numeric($_GET['rpp'])){
  $rpp = $_GET['rpp'];
}
if (isset($_GET['page']) && is_numeric($_GET['page'])){
  if (empty($rpp)){
   $rpp = 5;
  }
  $page = ($_GET['page'] - 1) * $rpp;
}
