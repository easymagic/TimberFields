<?php 
global $routeAction;
global $FE_PATH;
global $ClientSidebarMenu;
global $buffer;
global $hideSlider;

global $smartLink;

$smartLink = BASE_URL;

$ClientSidebarMenu = '';
$hideSlider = true;

$FE_PATH = BASE_URL . 'FE2/';


CallAction($routeAction . '_Client_Header');

CallAction('Client_Header');

// $top = $buffer;
// $buffer = '';

CallAction('Client_SideBarMenu');

// $side = $buffer;
// $buffer = '';

CallAction($routeAction . '_ClientContent');

// $content = $buffer;
// $buffer = '';

CallAction('Client_Custom');

// $content_custom = $buffer;
// $buffer = '';

// CallAction('Client_Destroy');

CallAction('Client_Footer');

// $footer = $buffer;


// $buffer = $top . $side . $content . $content_custom . $footer; //compose.



