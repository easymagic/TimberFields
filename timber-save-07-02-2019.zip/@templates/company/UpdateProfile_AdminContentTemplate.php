<section class="content-header">
      <h1>
        Update Company
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Update Company</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Company</h3>

              <a href="<?php echo BASE_URL; ?>Company/GetList" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

                <?php 
                 if (!empty($user_data['company_logo'])){
                ?>
                <div class="form-group">
                  <label for="exampleInputEmail1">
                    <img src="<?php echo BASE_URL; ?>uploads/user/companylogo/<?php echo $user_data['company_logo'] ?>" style="width: 128px;" />
                  </label>
                </div>
                <?php 
                 }
                ?>


                <div class="form-group">
                  <label for="exampleInputEmail1">Company Logo</label>
                  <input type="file" name="company_logo" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Company Name</label>
                  <input type="text" name="data[company_name]" class="form-control" id="exampleInputEmail1" placeholder="Company Name" value="<?php echo $user_data['company_name']; ?>" />
                </div>




                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <label>
                    &nbsp;(<?php echo $user_data['email']; ?>)
                  </label>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Charging Pattern</label>
                  <select id="charging_pattern" class="form-control" name="data[charging_pattern]">
                    <option value="platform">Platform</option>
                    <option value="rate-per-km">Rate Per KM</option>
                    <option value="company-defined-rate">Company Defined Rate</option>
                  </select>
                </div>



                <div class="form-group" id="charging_pattern_container" style="display: none;">
                  <label for="exampleInputEmail1">Charged Rate</label>
                  <input type="text" name="data[charged_rate]" class="form-control" id="exampleInputEmail1" placeholder="Charged Rate" value="<?php echo $user_data['charged_rate']; ?>" />
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="data[username]" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" value="<?php echo $user_data['username']; ?>">
                </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>
<script type="text/javascript">
  (function($){
    $(function(){

        function Visibility(cmd){
          $('#charging_pattern_container')[cmd]();
        }
        
        $('#charging_pattern').on('change',function(){
          var vl = $(this).val();
          if (vl == 'platform'){
            Visibility('hide'); 
          }else if (vl == 'rate-per-km'){
            Visibility('show');  
          }else if (vl == 'company-defined-rate'){
            Visibility('show');  
          }
        });

        $('#charging_pattern').val('<?php echo $user_data['charging_pattern']; ?>');
        $('#charging_pattern').trigger('change');



    });
  })(jQuery);
</script>