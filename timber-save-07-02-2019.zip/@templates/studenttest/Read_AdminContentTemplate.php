<?php 
 global $role;
 global $term;
 global $class;
?>
<script src="https://cdn.ckeditor.com/4.11.2/standard/ckeditor.js"></script>
<section class="content-header">
      <h1>
        Student Scores (<?php echo ucfirst($class); ?>/<?php echo ucfirst($term); ?>/<?php echo $subject_data['name']; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Student Scores</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Student Scores</h3>

<a href="<?php echo BASE_URL; ?>Test/Read/<?php echo $subject_data['id']; ?>?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-success btn-sm pull-right">Back</a>


            </div>
            <!-- /.box-header -->
            <div class="box-body">


<div class="col-xs-12">
  
  <div>
    <b>Test Question</b>
  </div>
  <div>
    <?php echo $test_data['content']; ?>  
  </div>


  <div>
    <b>Test Answer</b>
  </div>
  <div>
    <?php echo $test_data['correction']; ?>  
  </div>

</div>



              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Surname</th>
                  <th>First Name</th>
                  <th>Other Names</th>
                  <th>Date Created</th>
                </tr>

                <?php 
                  // foreach ($admin_data as $k=>$v){
                while (Iterate('student_test_data')){
                  $student = GetRow('student');
                ?>

                <tr>
                  <td><?php echo GetRowCount(); ?></td>
                  <td><?php echo $student['surname']; ?></td>
                  <td><?php echo $student['first_name']; ?></td>
                  <td><?php echo $student['other_names']; ?></td>
                  <!-- <td><?php //echo GetRow('email'); ?></td> -->
                  <td><?php echo GetRow('date_created'); ?></td>
                </tr>

                <tr>
                  
                   
                   <td></td>
                   <td colspan="4" data-view-ans="<?php echo GetRow('id'); ?>"> 

                    <div data-ans style="display: none;text-align: center;align-content: center;border: 1px solid #000;background-color: aliceblue;" align="center">
                      <h4 style="text-decoration: underline;">Student Answer</h4>
                      <div style="display: none;" data-activity>Saving ....... </div>
                      <textarea id="txt<?php echo GetRow('id'); ?>"><?php echo GetRow('student_response'); ?></textarea>
                    </div>

              <label class="btn btn-sm btn pull-right"><input type="checkbox" data-button />
                <span style="position: relative;top: -3px;">
                 View Answer    
                </span>
             </label>

                   </td>                    
                  
                </tr>



                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){

      function SaveStudentResponse(id,data,$act){
        ShowActivity($act,'slideDown');
        $.ajax({
          url:'<?php echo BASE_URL; ?>StudentTest/Update/' + id,
          type:'post',
          data:{
            data:{
              student_response:data
            }
          },
          success:function(response){
            // console.log(response,'saved.');
            ShowActivity($act,'slideUp');
          }
        });

      }

      function ShowActivity($el,cmd){
        $el[cmd](); 
        console.log($el); 
      }
      

      $('[data-view-ans]').each(function(){

         var $ans = $(this).find('[data-ans]');
         var $btn = $(this).find('[data-button]');
         var tgl = false;
         var id = $(this).data('view-ans');
         var $input = $(this).find('textarea');
         var $act = $(this).find('[data-activity]');

         $input.on('keyup',function(){
           SaveStudentResponse(id,$(this).val(),$act);
         });

         CKEDITOR.replace('txt' + id);

         CKEDITOR.instances['txt' + id].on("instanceReady",function(){
           
           this.document.on("keyup", function(){

             CKEDITOR.instances['txt' + id].updateElement();

             $input.trigger('keyup');

           });

         });

         $btn.on('click',function(){

           if (!tgl){
              $ans.slideDown(); 
           }else{
              $ans.slideUp();
           }
           tgl = !tgl;

         });

      });

    });
  })(jQuery);
</script>