<?php 
 global $FE_PATH;
 global $hideSlider;
 global $session;

 if ($hideSlider){
   $styleh = '17%';
 }else{
   $styleh = '';
 }
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <!--====== USEFULL META ======-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Transportation & Agency Template is a simple Smooth transportation and Agency Based Template" />
    <meta name="keywords" content="Portfolio, Agency, Onepage, Html, Business, Blog, Parallax" />

    <!--====== TITLE TAG ======-->
    <title>Welcome To TimberField Schools Lagos Student Portal</title>

    <!--====== FAVICON ICON =======-->
    <link rel="shortcut icon" type="image/ico" href="<?php echo $FE_PATH; ?>img/favicon.png" />

    <!--====== STYLESHEETS ======-->
    <link rel="stylesheet" href="<?php echo $FE_PATH; ?>css/normalize.css">
    <link rel="stylesheet" href="<?php echo $FE_PATH; ?>css/animate.css">
    <link rel="stylesheet" href="<?php echo $FE_PATH; ?>css/stellarnav.min.css">
    <link rel="stylesheet" href="<?php echo $FE_PATH; ?>css/owl.carousel.css">
    <link href="<?php echo $FE_PATH; ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $FE_PATH; ?>css/font-awesome.min.css" rel="stylesheet">

    <!--====== MAIN STYLESHEETS ======-->
    <link href="<?php echo $FE_PATH; ?>style.css" rel="stylesheet">
    <link href="<?php echo $FE_PATH; ?>css/responsive.css" rel="stylesheet">

    <!-- jQuery here -->
    <script src="<?php echo $FE_PATH; ?>js/vendor/jquery-1.12.4.min.js"></script>    

    <script src="<?php echo $FE_PATH; ?>js/vendor/modernizr-2.8.3.min.js"></script>
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body class="home-one">

    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>

    <!--START TOP AREA-->
    <header class="top-area" id="home" style="height: <?php echo $styleh; ?>">
        <div class="top-area-bg" data-stellar-background-ratio="0.6"></div>
        <div class="header-top-area">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area" style="border-bottom: 1px solid rgba(255, 255, 255,0.5);">
                <div class="mainmenu-area-bg"></div>
                <nav class="navbar">
                    <div class="container">
                        <div class="navbar-header">
                            
                            <a href="#home" class="navbar-brand">

                              <span style="color: #2ff45a;display: inline-block;margin-top: 13px;font-weight: bold;font-size: 15px;font-family: cursive;">
                                TIMBERFIELD SCHOOLS LAGOS
                              </span>

                              <!-- <img src="img/logo.png" alt="logo"> -->

                            </a>

                        </div>
                        <?php 
                         if (isset($session['student_session'])){
                        ?>
                        <div class="search-and-language-bar pull-right">
                            <ul>
                                <li><a href="<?php echo BASE_URL; ?>Home/StudentProfile"><i class="fa fa-user"></i></a></li>
                            </ul>
                        </div>
                        <?php 
                          }
                        ?>

<?php 
 global $smartLink;
?>

                        <div id="main-nav" class="stellarnav">
                            <ul id="nav" class="nav navbar-nav">
                                <li>
                                   <a href="<?php echo BASE_URL; ?>">home</a>
                                </li>
                                
                                <li>
                                  <a href="<?php echo $smartLink; ?>#about">about</a>
                                </li>

                                <li>
                                  <a href="<?php echo $smartLink; ?>#events">Events</a>
                                </li>

                                <li>
                                  <a href="<?php echo $smartLink; ?>#gallery">Gallery</a>
                                </li>

                                <li>
                                  <a href="<?php echo $smartLink; ?>#news">News</a>
                                </li>

                                <li>
                                  <a href="<?php echo $smartLink; ?>#pta">P.T.A</a>
                                </li>

<?php

 if (isset($session['student_session'])){
?>
                        <li>
                          <a href="<?php echo BASE_URL; ?>Home/StudentProfile">Profile</a>
                        </li>

                        <li>
                          <a style="color: red;" href="<?php echo BASE_URL; ?>Home/StudentLogOut">LOG OUT</a>
                        </li>

<?php 
 }else{
?>
                        <li>
                          <a href="<?php echo BASE_URL; ?>Home/StudentLogin">Student Login</a>
                        </li>
<?php 
 }
?>


                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <!--END MAINMENU AREA END-->
        </div>
<?php 
 if (!$hideSlider){
?>
        <!--HOME SLIDER AREA-->
        <div class="welcome-slider-area">
            <div class="welcome-single-slide slider-bg-one" style="background: url(<?php echo $FE_PATH; ?>bgs/bg3.jpg) no-repeat scroll center center / cover">
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1>A Building With Four Walls And Tomorrow Inside.</h1>
                                
<!--                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
 -->                                
<!--                                 <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
 -->                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="welcome-single-slide slider-bg-two" style="background: url(<?php echo $FE_PATH; ?>bgs/bg2.jpg) no-repeat scroll center center / cover">
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1>A Great Place For Education.</h1>

<!--                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
 -->                                
<!--                                 <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
 -->                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--END HOME SLIDER AREA-->
<?php 
 }
?>



    </header>
    <!--END TOP AREA-->






