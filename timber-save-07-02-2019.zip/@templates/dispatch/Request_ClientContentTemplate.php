<section class="main__middle__container">
  
<!--   <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
 -->

  <section class="recent-posts">
    <div class="container" style="
    width: 100%;
    padding: 0;
">

      <div class="row" style="padding-top: 0;padding: 0;margin: 0;/* width: 100%; */">
        <div class="col-xs-12" style="
    padding: 0;
"> 


   <div id="dvMap" style="height: 500px;">
   </div>

<!-- style="width: 100%; height: 500px;" -->
         
     <!-- [start] -->


<style type="text/css">
  .predictions-list-item:hover{
    background-color: #329832;
    color: #fff;
  }  


  @media(max-width: 768px){

     .handle-mobile{
      width: 80% !important;
     }

  }
</style>


<!-- rgba(0,0,0,0.2) -->
<form method="post" action="<?php echo BASE_URL; ?>Dispatch/SaveRequestSettings">
<div class="handle-mobile" style="position: absolute;top: 12%;margin-left: 11px;background-color: #fff;padding: 11px;width: 30%;">


<h2 style="margin-top: 5px;">
  REQUEST DISPATCH
</h2>

  <input autocomplete="off" type="text" class="form-control" id="pickup" name="pickup_address" placeholder="PICKUP LOCATION" style="display: inline-block;padding: 9px;border: 1px solid #777;width: 100%;margin-bottom: 11px;">


  <input autocomplete="off" type="text" class="form-control" id="dropoff" name="dropoff_address" placeholder="DROPOFF LOCATION" style="display: inline-block;padding: 9px;border: 1px solid #777;width: 100%;">


  <input type="hidden" name="pickup_lat" />
  <input type="hidden" name="pickup_lng" />

  <input type="hidden" name="dropoff_lat" />
  <input type="hidden" name="dropoff_lng" />

  <input type="hidden" name="dispatch_distance" />

<!--    <span style="
    background-color: #000;
    padding: 7px;
    display: inline-block;
    position: relative;
    top: 2px;
">

<svg viewBox="0 0 64 64" width="16px" height="16px" class=" _style_26XEsq" data-reactid="401" style="
    color: #fff;
    fill: currentColor;
"><path fill-rule="evenodd" clip-rule="evenodd" d="M59.9270592,31.9847012L60,32.061058L43.7665291,49.1333275l-3.2469215-3.5932007 L51.3236885,34H4v-4h47.3943481L40.5196075,18.4069672l3.2469215-3.4938126L60,31.946312L59.9270592,31.9847012z" data-reactid="402"></path></svg>     

   </span>
 -->
   <div id="ajax-status" style="display: none;">
     <img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/35771931234507.564a1d2403b3a.gif" style="height: 21px;">
   </div>
   
   <div id="predictions-list" style="
    padding: 5px;
    background-color: #fff;
    margin-top: 6px;
    border: 1px solid #777;
    display: none;
    position: absolute;
    z-index: 1000;
"></div>

   <div id="measured_distance" style="display: none;background-color: rgb(0, 0, 0); color: rgb(255, 255, 255); margin-top: 3px; padding: 3px;"></div>






   <!-- button -->
   <div>
     <input type="submit" style="color: #000;margin-top: 11px;line-height: 0;" name="proceed_button" class="btn btn-default btn-sm form-control" value="PROCEED" disabled="" />
   </div>
</div>
</form>


        

        <!-- [end]   -->
          
        </div>
      </div>
    </div>
  </section>
</section>


<script type="text/javascript">
  
       window.onload = function () {

        EventBus.Notify('InitMap',{
          mapId:"dvMap"
        });

        // EventBus.Notify('AddMarkers',{
        //   markers:markers
        // });

        // EventBus.Notify('DrawPath',{
        //   markers:markers
        // });

        EventBus.Notify('ZoomMap',{
          zoom:10
        });


        // EventBus.Subscribe('MapGetDistance',function(result){
        //   console.log(result);
        // });

        // EventBus.Notify('MapComputeDistance',{
        //   locationA:{
        //     lat:markers[0]['lat'],
        //     lng:markers[0]['lng']
        //   },
        //   locationB:{
        //     lat:markers[1]['lat'],
        //     lng:markers[1]['lng']
        //   }
        // });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:markers[1]['lat'],
        //   lng:markers[1]['lng'],
        //   radius:11
        // });


        EventBus.Notify('MapInitInputs',{
          pickup:'#pickup',
          dropoff:'#dropoff'
        });


       };


</script>