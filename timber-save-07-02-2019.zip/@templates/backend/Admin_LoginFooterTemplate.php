<?php
 $PATH = BASE_URL . 'BE2/';
?>
<script type="text/javascript">
    
    (function(){

      
       $(function(){

        setTimeout(function(){


            $('*[data-default]').each(function(){
                var vl = $(this).data('default');
                $(this).data(vl);
            });


        },1000);

            


       });   



    })(jQuery);

</script>


<script src="<?php echo $PATH; ?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/select2/select2.full.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo $PATH; ?>plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo $PATH; ?>plugins/input-mask/jquery.inputmask.extensions.js"></script>
<script src="<?php echo $PATH; ?>plugins/jQuery/moment.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo $PATH; ?>plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo $PATH; ?>plugins/fastclick/fastclick.js"></script>
<script src="<?php echo $PATH; ?>dist/js/app.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo $PATH; ?>dist/js/demo.js"></script>
<script src="<?php echo $PATH; ?>plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo $PATH; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>






<script>
    $(function () {


        $('#date_start').datepicker();
        $('#date_stop').datepicker();

        var date_start = '';
        var date_stop = '';

        $("#date_stop").datepicker( "option", "dateFormat", 'yy-mm-dd');
        $("#date_start").datepicker( "option", "dateFormat", 'yy-mm-dd');


        $('#date_start').val(date_start);
        $('#date_stop').val(date_stop);



        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
            showInputs: false
        });

        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
    });








</script>
</body>
</html>