
    <aside class="main-sidebar">
        <section class="sidebar">
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION (ADMIN)</li>
                <li class="active">
                    <a href="<?php echo BASE_URL; ?>User/Dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>



                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Accounts</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      
                      <li><a href="<?php echo BASE_URL; ?>Staff/GetList"><i class="fa fa-building-o"></i>Staffs</a></li>

                      <li><a href="<?php echo BASE_URL; ?>Student/Read"><i class="fa fa-building-o"></i>Students</a></li>
                      
<!--                       <li><a href="advert"><i class="fa fa-building-o"></i>Edit Profile</a></li>
 -->                      
                      <li><a href="<?php echo BASE_URL; ?>User/ChangeAccountPassword"><i class="fa fa-building-o"></i>Change Password</a></li>
                    </ul>
                </li>

                <?php 
                  global $classes;
                  global $terms;
                ?>
                 
                <li class="header">ACADEMICS</li>

                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Subjects</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <?php 
                       foreach ($classes as $k=>$v){
                        if ($k != 'graduate'){
                      ?>
                      <li>
                        <a href="#"><i class="treeview fa fa-building-o"></i>
                          
                          <span><?php echo ucfirst($k); ?></span> 
                          <span class="pull-right-container">
                              <i class="fa fa-angle-left pull-right"></i>
                          </span>                          

                        </a>
                        <ul class="treeview-menu">

                          <?php 
                           foreach ($terms as $k1=>$v1){
                             if ( strtolower($v1) != 'holiday'){
                          ?> 

                          <li><a href="<?php echo BASE_URL; ?>Subject/Read?term=<?php echo $v1; ?>&class=<?php echo $k; ?>"><i class="fa fa-building-o"></i>
                            <?php echo ucfirst($v1); ?>   
                          </a></li>

                          <?php 
                             }
                           }
                          ?>

                        </ul>
                      </li>
                      <?php 
                         }
                       }
                      ?>
                    </ul>
                </li>




<!--                 <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Academics</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      
                      <li><a href=""><i class="fa fa-building-o"></i>Subjects</a></li>
                      
                      <li><a href=""><i class="fa fa-building-o"></i>Tests</a></li>

                      <li><a href=""><i class="fa fa-building-o"></i>Assignments</a></li>

                      <li><a href=""><i class="fa fa-building-o"></i>Student Tests</a></li>


                      <li><a href=""><i class="fa fa-building-o"></i>Student Assignments</a></li>

                    </ul>
                </li>
 -->


            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>
<!-- content start -->
