<section class="content-header">
      <h1>
        Add GW-Setting
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add GW-Setting</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add GW-Setting</h3>

              <a href="<?php echo BASE_URL; ?>ManageSettings/ListSetting" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Setting Name</label>
                  <input type="text" name="data[name]" class="form-control" id="exampleInputEmail1" placeholder="Setting Name">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Setting Value</label>
                  <input type="text" name="data[value]" class="form-control" id="exampleInputPassword1" placeholder="Setting Value" />
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>


</div>

  <!-- /.col -->
</div>
</section>      