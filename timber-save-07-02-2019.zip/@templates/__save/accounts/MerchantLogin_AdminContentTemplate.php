<div class="login-box">
    <div class="login-logo">
        <a href="">
        	<img src="Fordepro_logo.png" alt="" style="height: 75px" />
        </a>
        MERCHANT LOGIN
    </div>
    <div class="login-box-body">
    

        <div class="col-xs-12">
          <?php 
            if (isset($message)){
              echo $message;
            }
           ?>
        </div>
        <div style="clear: both;"></div>
        <form action="" method="post" autocomplete="off">
            <div class="form-group has-feedback">
                <input type="text" class="form-control" name="email" autocomplete="off" placeholder="Username">
                <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" name="password" placeholder="Password">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <div class="col-xs-4">
                    <button type="submit" name="login" class="btn btn-primary btn-block btn-flat">Sign In</button>
                </div>
            </div>
        </form>

        

    </div>
</div>