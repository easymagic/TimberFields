<?php 
 if (isset($message)){
  echo $message;
 }
?>
<div>
	<b>Very cool.</b>
</div>

Playing ... <form method="post"><input type="text" name="data[name]" /><button>Play</button></form>:' . <?php echo count($test_test_data); ?>