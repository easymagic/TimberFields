<?php 
 global $classes;
 global $terms;
 global $term;
 global $class;
?>
<script src="https://cdn.ckeditor.com/4.11.2/standard/ckeditor.js"></script>
<section class="content-header">
      <h1>
        Publish Test (<?php echo ucfirst($class); ?>/<?php echo ucfirst($term); ?>/<?php echo $subject_data['name']; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Publish Test</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Publish Test</h3>

              <a href="<?php echo BASE_URL; ?>Test/Read/<?php echo $subject_id; ?>?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data" onsubmit="return confirm('Have you reviewed this test, because you cannot modify once published.')">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->



                <div class="form-group">
                  <label for="">Test Content</label>
                  <textarea name="data[content]" id="content" class="form-control" placeholder="Test Content"></textarea>
                </div>


                <div class="form-group">
                  <label for="">Test Correction</label>
                  <textarea name="data[correction]" id="correction" class="form-control" placeholder="Test Correction"></textarea>
                </div>




              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Publish</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){
          


         CKEDITOR.replace( 'content' );
         CKEDITOR.replace( 'correction' );

    });
  })(jQuery);
</script>

