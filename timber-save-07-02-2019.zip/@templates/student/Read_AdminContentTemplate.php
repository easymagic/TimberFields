<?php 
 global $role;
?>
<section class="content-header">
      <h1>
        Student
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Students</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Students</h3>

              <a href="<?php echo BASE_URL; ?>Student/Register" class="btn btn-success btn-sm pull-right"> + Add Student</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Passport</th>
                  <th>Surname</th>
                  <th>First Name</th>
                  <th>Other Names</th>
                  <!-- <th>E-mail</th> -->
                  <th>E-mail (Guardian)</th>
                  <!-- <th>Status</th> -->
                  <th>Operations</th>
                </tr>

                <?php 
                  // foreach ($admin_data as $k=>$v){
                while (Iterate('student_data')){
                ?>

                <tr>
                  <td><?php echo GetRowCount(); ?></td>
                  <td>
                    <img style="width: 32px;" src="<?php echo BASE_URL; ?>uploads/student/studentpassport/<?php echo GetRow('passport'); ?>">
                  </td>
                  <td><?php echo GetRow('surname'); ?></td>
                  <td><?php echo GetRow('first_name'); ?></td>
                  <td><?php echo GetRow('other_names'); ?></td>
                  <!-- <td><?php //echo GetRow('email'); ?></td> -->
                  <td><?php echo GetRow('guardian_email'); ?></td>
                  <td>

                     <a href="<?php echo BASE_URL; ?>Student/Update/<?php echo GetRow('id'); ?>" class="btn btn-default btn-sm">Edit</a>

                     <a href="<?php echo BASE_URL; ?>Student/ChangePassword/<?php echo GetRow('id'); ?>" class="btn btn-default btn-sm">Change Password</a>


<!--                      <?php 
                      // if ($role == 'admin'){
                      // if (GetRow('status') == 1){
                    ?>

                    <a class="btn btn-sm btn-danger confirm" href="<?php //echo BASE_URL; ?>Staff/DisableStatus/<?php //echo GetRow('id'); ?>">Disable Account</a>
                    <?php 
                      // }else{
                    ?>
                    <a class="btn btn-sm btn-success confirm" href="<?php //echo BASE_URL; ?>Staff/EnableStatus/<?php //echo GetRow('id'); ?>">Enable Account</a>
                    <?php 
                     //  }
                     // }
                     ?>
 -->                  </td>
                </tr>

                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      