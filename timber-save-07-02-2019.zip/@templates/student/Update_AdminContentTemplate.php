<?php 
 global $classes;
 global $terms;
 global $term;
 global $class;
?>
<section class="content-header">
      <h1>
        Update Student
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Update Student</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Student</h3>

              <a href="<?php echo BASE_URL; ?>Student/Read" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->

 <div style="border-bottom: 1px solid #222;margin-bottom: 12px;">
   <b>SCHOOL DETAILS</b>
 </div>


                <div class="form-group">
                  <label for="">Class</label>
                  <select class="form-control" name="data[class]" data-value="<?php echo $student_data['class']; ?>">
                    <?php 
                     foreach ($classes as $k=>$v){
                    ?>
                    <option value="<?php echo $k; ?>"><?php echo $k; ?></option>
                    <?php 
                     }
                    ?>
                  </select>
                </div>


                <div class="form-group">
                  <label for="">Term</label>
                  <select class="form-control" name="data[term]" data-value="<?php echo $student_data['term']; ?>">
                    <?php 
                      foreach ($terms as $k=>$v){
                    ?>
                    <option value="<?php echo $v; ?>"><?php echo $v; ?></option>
                    <?php 
                     }
                    ?>
                  </select>
                </div>


                <div class="form-group" align="right">
                  
                  <?php 
                    
                    if (!empty($student_data['passport'])){
                  ?>     
                  <img style="width: 64px;" src="<?php echo BASE_URL; ?>uploads/student/studentpassport/<?php echo $student_data['passport']; ?>" />
                  <?php 
                    }

                  ?>


                </div>


                <div class="form-group">
                  <label for="">Passport-Photograph</label>
                  <input type="file" name="passport" class="form-control"  placeholder="Upload Passport.">
                </div>




 <div style="border-bottom: 1px solid #222;margin-bottom: 12px;">
   <b>BIO</b>
 </div>

 

                <div class="form-group">
                  <label for="">Surname</label>
                  <input type="text" name="data[surname]" class="form-control"  placeholder="Surname" value="<?php echo $student_data['surname']; ?>">
                </div>

                <div class="form-group">
                  <label for="">First Name</label>
                  <input type="text" name="data[first_name]" class="form-control"  placeholder="First Name"  value="<?php echo $student_data['first_name']; ?>">
                </div>


                <div class="form-group">
                  <label for="">Other Names</label>
                  <input type="text" name="data[other_names]" class="form-control"  placeholder="Other Names"  value="<?php echo $student_data['other_names']; ?>">
                </div>

                <div class="form-group">
                  <label for="">Gender</label>
                  <select class="form-control" name="data[gender]" data-value="<?php echo $student_data['gender']; ?>">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>



              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){
          

          $('[data-value]').each(function(){
            var vl = $(this).data('value');
            $(this).val(vl);
          });

    });
  })(jQuery);
</script>