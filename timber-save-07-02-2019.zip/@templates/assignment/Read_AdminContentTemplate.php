<?php 
 global $role;
 global $term;
 global $class;
?>
<section class="content-header">
      <h1>
        Assignment (<?php echo ucfirst($class); ?>/<?php echo ucfirst($term); ?>/<?php echo $subject_data['name']; ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">List Assignments</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Assignments</h3>

              <a style="margin-left: 5px;" href="<?php echo BASE_URL; ?>Subject/Read?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-default btn-sm pull-right">Back</a>


              <a href="<?php echo BASE_URL; ?>Assignment/Create/<?php echo $subject_data['id']; ?>?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-success btn-sm pull-right">Publish Assignment</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tbody>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Class</th>
                  <th>Term</th>
                  <th>Date Added</th>
                  <!-- <th>E-mail</th> -->
                  <!-- <th>Status</th> -->
                  <th>Operations</th>
                </tr>

                <?php 
                  // foreach ($admin_data as $k=>$v){
                while (Iterate('assignment_data')){
                ?>

                <tr>
                  <td><?php echo GetRowCount(); ?></td>
                  <td><?php echo GetRow('class'); ?></td>
                  <td><?php echo GetRow('term'); ?></td>
                  <!-- <td><?php //echo GetRow('email'); ?></td> -->
                  <td><?php echo GetRow('date_created'); ?></td>
                  <td>

                     <a href="<?php echo BASE_URL; ?>Assignment/ReadOne/<?php echo GetRow('id'); ?>" class="btn btn-default btn-sm">Detail</a>


                     <a href="<?php echo BASE_URL; ?>StudentAssignment/Read/<?php echo GetRow('id'); ?>?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-default btn-warning">Student Scores</a>



<!--                      <?php 
                      // if ($role == 'admin'){
                      // if (GetRow('status') == 1){
                    ?>

                    <a class="btn btn-sm btn-danger confirm" href="<?php //echo BASE_URL; ?>Staff/DisableStatus/<?php //echo GetRow('id'); ?>">Disable Account</a>
                    <?php 
                      // }else{
                    ?>
                    <a class="btn btn-sm btn-success confirm" href="<?php //echo BASE_URL; ?>Staff/EnableStatus/<?php //echo GetRow('id'); ?>">Enable Account</a>
                    <?php 
                     //  }
                     // }
                     ?>
 -->                  </td>
                </tr>

                <?php 
                 }
                ?>


              </tbody></table>
            </div>
            <!-- /.box-body -->
            
<!--             <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
 -->
          </div>
          <!-- /.box -->

        </div>

  <!-- /.col -->
</div>
</section>      