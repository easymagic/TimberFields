<?php 
 global $classes;
 global $terms;
 global $term;
 global $class;
?>
<section class="content-header">
      <h1>
        Add Subject (<?php echo ucfirst($class); ?>/<?php echo ucfirst($term); ?>)
        <!-- <small>Version 2.0</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add Subject</li>
      </ol>
</section>


<section class="content">
<div class="row">


<div class="col-md-8">
          




<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add Subject</h3>

              <a href="<?php echo BASE_URL; ?>Subject/Read?term=<?php echo $term; ?>&class=<?php echo $class; ?>" class="btn btn-primary btn-sm pull-right">Back</a>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data">
              <div class="box-body">

<!--                 <div class="form-group">
                  <label for="">Account Type</label>
                  <select class="form-control" name="data[account_type]">
                    <option value="individual">Individual</option>
                    <option value="corporate">Corporate</option>
                  </select>
                </div>
 -->



                <div class="form-group">
                  <label for="">Subject Name</label>
                  <input type="text" name="data[name]" class="form-control"  placeholder="Subject Name">
                </div>

                <input type="hidden" name="data[term]" value="<?php echo $term; ?>" />
                <input type="hidden" name="data[class]" value="<?php echo $class; ?>" />



              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>

          

</div>

  <!-- /.col -->
</div>
</section>      
<script type="text/javascript">
  (function($){
    $(function(){
          

          $('[data-value]').each(function(){
            var vl = $(this).data('value');
            $(this).val(vl);
          });

    });
  })(jQuery);
</script>