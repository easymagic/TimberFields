<!-- side bar. -->
<div class="col-xs-12 col-md-3">

<?php 
 global $currentTerm;
 global $session;
?>	 

	 <ul class="list-group">

	 	<li>
	 		<img src="<?php echo BASE_URL; ?>uploads/student/studentpassport/<?php echo $session['student_session']['passport']; ?>" />
	 	</li>

	 	 <li class="list-group-item">
	 	 	 <u><i><b><?php echo ucfirst($currentTerm); ?></b></i></u>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>Home/StudentProfile">
	 	 		<b>Profile</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>Home/StudentChangePassword">
	 	 		<b>Change Password</b>
	 	 	</a>
	 	 </li>
	 	

	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>Home/StudentTests">
	 	 		<b>Tests</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a href="<?php echo BASE_URL; ?>Home/StudentAssignments">
	 	 		<b>Assignments</b>
	 	 	</a>
	 	 </li>


	 	 <li class="list-group-item">
	 	 	<a style="color: red;" href="<?php echo BASE_URL; ?>Home/StudentLogOut">
	 	 		<b>Log Out</b>
	 	 	</a>
	 	 </li>

	 </ul>


</div>