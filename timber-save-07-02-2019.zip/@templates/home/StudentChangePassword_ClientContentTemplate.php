<?php 
global $FE_PATH; 
?>
<style type="text/css">
  section{
    padding-top: 0 !important;
    min-height: 512px;
  }
</style>
    <!--about AREA-->
    <section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top" style="padding-top: 25px;">
            <div class="container">
                <div class="row">

                    <div class="col-sm-12 col-xs-12 col-md-8 col-md-offset-2">
                      <?php 
                       if (isset($message)){
                        if (isset($error) && $error){
                          $cls = 'danger';
                        }else{
                          $cls = 'info';
                        }
                      ?>
                      <div class="col-xs-12">
                        <div align="center" class="alert alert-<?php echo $cls; ?>"><b><?php echo $message; ?></b></div>
                      </div>
                      <?php 
                       }
                      ?>
                        <div class="area-title text-center wow fadeIn" style="margin-bottom: 0;">
                            <!-- <h2>Profile</h2> -->
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-xs-12  col-md-8 col-md-offset-2">
                        <div class="service-content wow fadeIn">
                          


<?php 
 echo $sidebar;
?>

<div class="col-xs-12 col-md-9">
   

      <div class="form-group">
        <u><b>CHANGE PASSWORD</b></u>
      </div>

      <form method="post">


        <div class="form-group">
          <input type="password" name="password1" class="form-control" placeholder="Password" />
        </div>

        <div class="form-group">
          <input type="password" name="password2" class="form-control" placeholder="Confirm Password" />
        </div>


        <div class="form-group">
          <input type="submit" class="form-control btn btn-info" value="CHANGE PASSWORD" />
        </div>


        
      </form>



</div>




                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--about AREA END-->

