<?php 
global $FE_PATH; 
?>
<style type="text/css">
  section{
    padding-top: 0 !important;
    min-height: 512px;
  }
</style>
    <!--about AREA-->
    <section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top" style="padding-top: 25px;">
            <div class="container">
                <div class="row">

                    <div class="col-sm-12 col-xs-12 col-md-8 col-md-offset-2">
                      <?php 
                       if (isset($message)){
                        if (isset($error) && $error){
                          $cls = 'danger';
                        }else{
                          $cls = 'info';
                        }
                      ?>
                      <div class="col-xs-12">
                        <div align="center" class="alert alert-<?php echo $cls; ?>"><b><?php echo $message; ?></b></div>
                      </div>
                      <?php 
                       }
                      ?>
                        <div class="area-title text-center wow fadeIn" style="margin-bottom: 0;">
                            <!-- <h2>Profile</h2> -->
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-8 col-md-offset-2">
                        <div class="service-content wow fadeIn">
                          


<?php 
 echo $sidebar;
?>

<div class="col-xs-12 col-md-9" style="padding: 0;">
   
  
    <div class="form-group" align="right">
      <a href="<?php echo BASE_URL; ?>Home/StudentAssignments" class="btn btn-sm btn-primary">Back</a>
    </div>


      <div class="form-group">
        <u><b>ASSIGNMENT DETAIL (<?php echo $subject_data['name']; ?> , <?php echo $student_assignment_data['term']; ?> , <?php echo $student_assignment_data['class']; ?>)</b></u>
      </div>



      <div class="form-group">


<form method="post">
  

  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Question</u> : </label>

  </div>

  <div class="form-group" style="
    border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">
    <?php echo $assignment_data['content']; ?>
  </div>
  
  <?php 
    if (empty($student_assignment_data['correction'])){

   ?>
   
   <div class="form-group">
      
        <textarea class="form-control" name="data[student_response]" placeholder="Type Your Answer Here"><?php echo $student_assignment_data['student_response']; ?></textarea>

   </div>


   <div class="form-group">
    <input type="submit" value="Submit Assignment" class="form-control btn btn-success" />
   </div> 


   <?php    

    }else{

    
    ?>

  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Correction</u> : </label>

  </div>

  <div class="form-group" style="
    border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">
    <?php echo $student_assignment_data['correction']; ?>
  </div>


  <div class="form-group" style="margin-bottom: 0;">
     
     <label><u>Student Response</u> : </label>

  </div>

  <div class="form-group" style="
    border: 1px solid #bbb;background-color: #eee;padding: 9px;font-weight: bold;">
    <?php echo $student_assignment_data['student_response']; ?>
  </div>



   <div class="form-group">
     <div class="alert alert-warning">
       <b>This assignment cannot be further edited, it has already been corrected.</b>
     </div>
   </div> 

    <?php 


    }
  ?>




</form>










      </div>






</div>




                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--about AREA END-->

