<?php 
global $FE_PATH; 
?>
<style type="text/css">
  section{
    padding-top: 0 !important;
    min-height: 512px;
  }
</style>
    <!--about AREA-->
    <section class="blog-area gray-bg padding-top" id="about">
        <div class="service-top-area padding-top" style="padding-top: 25px;">
            <div class="container">
                <div class="row">

                    <div class="col-sm-12 col-xs-12 col-md-8 col-md-offset-2">
                      <?php 
                       if (isset($message)){
                        if (isset($error) && $error){
                          $cls = 'danger';
                        }else{
                          $cls = 'info';
                        }
                      ?>
                      <div class="col-xs-12">
                        <div align="center" class="alert alert-<?php echo $cls; ?>"><b><?php echo $message; ?></b></div>
                      </div>
                      <?php 
                       }
                      ?>
                        <div class="area-title text-center wow fadeIn" style="margin-bottom: 0;">
                            <!-- <h2>Profile</h2> -->
                            
<!--                             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
 -->

                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-xs-12 col-md-8 col-md-offset-2">
                        <div class="service-content wow fadeIn">
                          


<?php 
 echo $sidebar;
?>

<div class="col-xs-12 col-md-9" style="padding: 0;">
   

      <div class="form-group">
        <u><b>TESTS</b></u>
      </div>


      <div class="form-group">
        <table class="table">
          <tr>
              <th>
                #
              </th>
              <th>
                Subject
              </th>
              <th>
                Term
              </th>
              <th>
                Class
              </th>

              <th>
                Date
              </th>

              <th>
                Operations
              </th>
            
          </tr>
          <?php 
            foreach ($student_test_data as $k=>$v){
              // print_r($student_test_data);
          ?>

           <tr>
             <td><?php echo $k+1; ?></td>
             <td><?php echo $v['subject']['name']; ?></td>
             <td><?php echo $v['term']; ?></td>
             <td><?php echo $v['class']; ?></td>
             <td><?php echo $v['date_created']; ?></td>
             <td>
               <a href="<?php echo BASE_URL; ?>Home/StudentTestDetail/<?php echo base64_encode($v['id']); ?>" class="btn btn-sm btn-info">Detail</a>
             </td>
           </tr>

          <?php 
            }
          ?>
        </table>
      </div>






</div>




                        </div>
                    </div>



                </div>
            </div>
        </div>
    </section>
    <!--about AREA END-->

