<?php 
/**

@Inject(app-x/core/EmailQueue);

*/

class MailQueueThread{
    
    private $called = false;
    
    

	function Run(){
	  global $emailQueue;
	  if (!isset($emailQueue)){
        $emailQueue = array(); 
	  }
      $this->DoEvents(); 
	}



	function DoEvents(){
     global $emailQueue;
    
    //subject,message,to,from
    foreach ($emailQueue as $k=>$v){
       if (isset($v['subject']) && isset($v['message']) && isset($v['to']) && isset($v['from'])){
         $this->EmailQueue->SetSubject($v['subject']); 
         $this->EmailQueue->SetMessage($v['message']);
         $this->EmailQueue->SetTo($v['to']);
         $this->EmailQueue->SetFrom($v['from']);
         $this->EmailQueue->Send();
       }
    }
    $emailQueue = array(); //clear the queue.


	}

  
  


}