<?php 

class Input{

  

  function Val($vl,$name='data'){
    global $data;
    // print_r($data);
    // print_r(array_keys($data));
    // $data_ = InjectViewClass::GetKey($name);
    if (empty($data)){
     return '';
    }else{
      // print_r($data[$name]);
     if (isset($data[$name]) && isset($data[$name][$vl])){
       return $data[$name][$vl];
     }else{
       return ''; 
     }
    }
    
  }


}