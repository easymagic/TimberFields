<?php 

/**

@Inject(@services/Db,
        @services/View);


*/


class Repository{
  
  private $entity = '';
  private $params = array();

    private function DecodeParams($cmd){
      
      $r = explode('@', $cmd);
      $this->entity = array_shift($r);
      $paramsText = array_shift($r);
      if (!empty($paramsText)){
         $paramsText = explode(',', $paramsText);
         foreach ($paramsText as $k=>$v){

           $t = explode('=', $v);
           $key = array_shift($t);
           $value = array_shift($t);

           if (!empty($key)){
             $this->params[$key] = $value;
           }

         }
      }

    }

    private function EvalResource(){
      $c = -1;
      if (!empty($this->params)){
        foreach ($this->params as $k=>$v){
          ++$c;
          if ($c == 0){
            $this->Db->Where($k,$v);
          }else{
            $this->Db->And($k,$v);
          }
        }
      }
      if (!empty($this->entity)){
        $record = $this->Db->Get($this->entity);
        $dataKey = $this->entity . '_data';
        $this->View->$dataKey = $record;
      }
    }  
     
    function UseResource($cmd){
       $this->DecodeParams($cmd);
       $this->EvalResource();
    }
    
  

}