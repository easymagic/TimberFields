<?php
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/
class User{

  
  function Init(){

    global $UserChangeAccountPassword_Action_Redirect;
    global $UserLogOut_Redirect;

    $UserChangeAccountPassword_Action_Redirect = 'User/Dashboard';
    $UserLogOut_Redirect = 'Auth/LogIn';

    
    InstallTheme('@themes/AdminBackEndFramework');

    // InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);
    
  }

  function Index(){
  	echo 'index.. loaded.';
  }

  function ChangeAccountPassword_AdminContent(){}


}