<?php 
class Home{

   
   function Init(){
   }

   function Index(){
   	// echo 'Index loaded ... ';
   }   

   function Play_Virtual(){
   	// global $buffer;
   	// global $model;
   	// // $model = array('@models/Test/TestGetList','GetList');
   	// $buffer.= 'Init from virtual.'; 
   }

   function Play_Action_Virtual(){
   	// global $model;
    // $model = array('@models/Test/TestCreate_Action','Create_Action');   	
   }

   
   function Play(){
   	// global $buffer;
   	// global $data;
   	// global $template;
   	// global $currentTerm;
   	// global $classes;
   	// // $data['currentTerm'] = $currentTerm;
   	// echo $currentTerm;
   	// print_r($classes);
   	// $template = '@templates/test/ply';
   }



}