<?php 
/**
@Inject(@plugins/apis/UserPlugin,
        @plugins/authlogged/AdminBackEndPlugin,
        @plugins/ai/BrainChildPlugin);
*/

class Staff{
  

  function Init(){
  	global $me;

    global $aliasModel;

    global $UserUpdateProfile_Action_Redirect;
    global $UserChangePassword_Action_Redirect;
    global $UserDisableStatus_Redirect;
    global $UserEnableStatus_Redirect;
    global $UserRegister_Action_Redirect;

    $me = 'Staff';

    $UserUpdateProfile_Action_Redirect = $me . '/GetList';
    $UserChangePassword_Action_Redirect = $me . '/GetList';
    $UserDisableStatus_Redirect = $me . '/GetList';
    $UserEnableStatus_Redirect = $me . '/GetList';
    $UserRegister_Action_Redirect = $me . '/GetList';
    

    
   
    $aliasModel = 'User';

  	

  	
    
    InstallTheme('@themes/AdminBackEndFramework');

    // InstallPlugin($this->UserPlugin);
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->BrainChildPlugin);

    

  }

  function Page_Init(){
  	global $postData;
    $postData['role'] = 'staff'; //set this by default from the server-side for security reasons.
  }

  function Before_GetList(){
  	global $db_where;
  	global $parent_id;
  	$this->EntityRead->SetWhere("role='staff'");
  	$this->EntityRead->SetWhere("parent_id=$parent_id");

  }

  function GetList_AdminContent(){
  	global $db_query_log;
  	// print_r($db_query_log);
  }

  function UpdateProfile_AdminContent(){}
  function ChangePassword_AdminContent(){}
  function Register_AdminContent(){}
  function EnableStatus_AdminContent(){}
  function DisableStatus_AdminContent(){}




}