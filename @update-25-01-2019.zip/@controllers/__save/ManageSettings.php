<?php 

/**

@Inject(@plugins/AdminBackEndPlugin,
        @plugins/admin/ManageSettingsPlugin);


*/


class ManageSettings{
  
  function Init(){
    InstallPlugin($this->AdminBackEndPlugin);
    InstallPlugin($this->ManageSettingsPlugin);

    InstallTheme('@themes/AdminBackEndFramework');
  }
  
  function ListSetting_AdminContent(){}
  function EditSetting_AdminContent(){}
  function AddSetting_AdminContent(){}



}
 