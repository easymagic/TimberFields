<?php 
/**
@Inject(@models/entityv2/EntityRead,
        @models/SiteSettings/SiteSettingsGetOption);
*/


class UserGetList{


  function GetList(){
   global $charging_flat_rate;
   $this->EntityRead->Read('user');
   $charging_flat_rate = $this->SiteSettingsGetOption->GetOption('charging_flat_rate');
  }


}