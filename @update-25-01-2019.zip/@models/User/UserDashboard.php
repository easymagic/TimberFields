<?php
/**
@Inject(@models/User/metrics/UserGetCount,
        @models/Customer/metrics/CustomerGetCount,
        @models/DispatchRequest/metrics/DispatchRequestGetCount,
        @models/User/filters/UserFilterDispatcher,
        @models/DispatchRequest/filters/DispatchRequestFilterPending,
        @models/DispatchRequest/filters/DispatchRequestFilterDroppedOff);
*/

class UserDashboard{

  


  function Dashboard(){
      global $data;
      global $parent_id;
      global $role;

    	
      
      if ($role != 'admin'){
        $this->EntityRead->SetWhere("parent_id=$parent_id");
      }      
      $data['user_count'] = $this->UserGetCount->GetCount();


      $data['customer_count'] = number_format($this->CustomerGetCount->GetCount());

      // $this->EntityRead->SetWhere("parent_id=$parent_id");
      if ($role != 'admin'){
        $this->EntityRead->SetWhere("parent_id=$parent_id");
      }            
      $this->UserFilterDispatcher->FilterDispatcher();
      $data['dispatcher_count'] = number_format($this->UserGetCount->GetCount());

      // $this->EntityRead->SetWhere("user_parent_id=$parent_id");
      if ($role != 'admin'){
        $this->EntityRead->SetWhere("parent_id=$parent_id");
      }            
      $this->DispatchRequestFilterPending->FilterPending(); //user_parent_id
      $data['pending_dispatch_count'] = number_format($this->DispatchRequestGetCount->GetCount());

      // $this->EntityRead->SetWhere("user_parent_id=$parent_id");
      if ($role != 'admin'){
        $this->EntityRead->SetWhere("parent_id=$parent_id");
      }            
      $this->DispatchRequestFilterDroppedOff->FilterDroppedOff();
      $data['confirmed_dispatch_count'] = number_format($this->DispatchRequestGetCount->GetCount());

  }



}