<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/
class UserGetBusyStatus{
  //dispatch_availability

  function GetBusyStatus($id){
     global $data;

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityReadOne->ReadOne('user');
     
     return $data['user_data']['dispatch_availability'];

  }


}