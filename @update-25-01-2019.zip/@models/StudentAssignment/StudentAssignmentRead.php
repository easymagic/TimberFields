<?php 

class StudentAssignmentRead{
  

    function Read(){
    	$this->EntityRead->Read('student_assignment');
    }


}