<?php 

class StudentAssignmentReadOne{

    function ReadOne($id){

    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('student_assignment');

    }

}