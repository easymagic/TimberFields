<?php 

class AssignmentReadOne{


    function Read($id){
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('assignment');
    }

}