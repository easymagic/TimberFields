<?php
/**
@Inject(@models/Student/StudentRead,
        @models/StudentAssignment/StudentAssignmentCreate_Action);
*/
class AssignmentCreate_Action{


     function Create_Action(){
     	global $postData;
     	global $data;     	
     	global $currentTerm;
     	global $newID;

     	$class = $postData['class'];

     	$postData['date_created'] = date('Y-m-d h:i:s');

     	$this->EntityRead->SetWhere("term='$currentTerm'");
     	$this->EntityRead->SetWhere("class='$class'");
     	$this->StudentRead->Read();

        $this->EntityCreate->SetData($postData);
        // echo 'A called.';
        $this->EntityCreate->DoCreate('assignment');
        $new_assignment_id = $newID;

        foreach ($data['student_data'] as $k=>$student){

           $postData = array();
           $postData['assignment_id']	= $new_assignment_id;
           $postData['term'] = $currentTerm;
           $postData['class'] = $class;
           $postData['student_id'] = $student['id'];
           $postData['date_created'] = date('Y-m-d h:i:s');
            
           $this->StudentAssignmentCreate_Action->Create_Action();

        }


        $data['message'] = 'Assignment Created and notification sent.';
        
     }

}