<?php 

class AssignmentRead{


    
    function Read(){
    	$this->EntityRead->Read('assignment');
    }

}