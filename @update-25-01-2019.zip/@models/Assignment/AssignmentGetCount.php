<?php 

class AssignmentGetCount{
  


  function GetCount(){
  	return $this->EntityCount->GetCount('assignment');
  }


}