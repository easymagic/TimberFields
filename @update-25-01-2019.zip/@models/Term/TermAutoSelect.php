<?php 

class TermAutoSelect{
  
  private $months = array(
   'Jan'=>1,
   'Feb'=>2,
   'Mar'=>3,
   'Apr'=>4,
   'May'=>5,
   'Jun'=>6,
   'Jul'=>7,
   'Aug'=>8,
   'Sep'=>9,
   'Oct'=>10,
   'Nov'=>11,
   'Dec'=>12
  );
  

  function Init(){
  	
  	$this->AutoSelect();
  }

  function AutoSelect(){
    global $currentTerm;

    $day = +date('d');
    $month = +date('m');
    $year = +date('y');

    if ($month >= $this->months['Sep'] && $month <= $this->months['Dec']){
     $currentTerm = 'first-term';
    }else if ($month >= $this->months['Jan'] && $month <= $this->months['Apr']){
     $currentTerm = 'second-term';
    }else if ($month >= $this->months['May'] && $month <= $this->months['Jul']){
     $currentTerm = 'third-term';
    }else{
     $currentTerm = 'Holiday';  	
    }

    // echo "$day,$month,$year<br />";

  }
  

}