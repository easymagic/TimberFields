<?php 
/**
@Inject(@models/StudentTest/StudentTestUpdate_Action);
*/
class StudentTestProfileUpdate_Action{
  

   function ProfileUpdate_Action($id){
    global $session;
    $student_id = $session['student_session']['id'];
    $this->EntityRead->SetWhere("student_id='$student_id");
    $this->StudentTestUpdate_Action->Update_Action($id);
   }
  

}