<?php 

class StudentTestRead{
  

    function Read(){
    	$this->EntityRead->Read('student_test');
    }


}