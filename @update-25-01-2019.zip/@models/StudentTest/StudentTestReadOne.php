<?php 

class StudentTestReadOne{

    function ReadOne($id){

    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('student_test');

    }

}