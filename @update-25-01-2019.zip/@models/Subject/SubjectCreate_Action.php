<?php 
class SubjectCreate_Action{


     function Create_Action(){
     	global $postData;
     	
     	$this->EntityCreate->SetData($postData);
     	$this->EntityCreate->DoCreate('subject');

        $data['message'] = 'Subject Created.';
     }

}