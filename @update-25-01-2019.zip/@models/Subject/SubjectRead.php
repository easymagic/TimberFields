<?php 
class SubjectRead{


     function Read(){
     	$this->EntityRead->Read('subject');
     }

}