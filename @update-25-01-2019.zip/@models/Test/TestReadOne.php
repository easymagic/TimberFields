<?php 

class TestReadOne{


    function Read($id){
    	$this->EntityRead->SetWhere("id=$id");
    	$this->EntityReadOne->ReadOne('test');
    }

}