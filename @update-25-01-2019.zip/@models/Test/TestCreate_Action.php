<?php
/**
@Inject(@models/Student/StudentRead,
        @models/StudentTest/StudentTestCreate_Action);
*/
class TestCreate_Action{


     function Create_Action(){
     	global $postData;
     	global $data;     	
     	global $currentTerm;
     	global $newID;

     	$class = $postData['class'];

     	$postData['date_created'] = date('Y-m-d h:i:s');

     	$this->EntityRead->SetWhere("term='$currentTerm'");
     	$this->EntityRead->SetWhere("class='$class'");
     	$this->StudentRead->Read();

        $this->EntityCreate->SetData($postData);
        // echo 'A called.';
        $this->EntityCreate->DoCreate('test');
        $new_test_id = $newID;

        foreach ($data['student_data'] as $k=>$student){

           $postData = array();
           $postData['test_id']	= $new_test_id;
           $postData['term'] = $currentTerm;
           $postData['class'] = $class;
           $postData['student_id'] = $student['id'];
           $postData['date_created'] = date('Y-m-d h:i:s');
            
           $this->StudentTestCreate_Action->Create_Action();

        }


        $data['message'] = 'Test Created and notification sent.';
        
     }

}