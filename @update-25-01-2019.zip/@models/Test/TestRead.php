<?php 

class TestRead{


    
    function Read(){
    	$this->EntityRead->Read('test');
    }

}