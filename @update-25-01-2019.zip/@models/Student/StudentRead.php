<?php 

class StudentRead{

  
  function Read(){
  	$this->EntityRead->Read('student');
  }



}