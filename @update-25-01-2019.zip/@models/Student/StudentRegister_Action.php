<?php 

class StudentRegister_Action{

  
  function Register_Action(){
  	$this->EntityAccountCreate->AccountCreate('student');
  } 


}