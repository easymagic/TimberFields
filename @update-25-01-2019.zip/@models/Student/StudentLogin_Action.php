<?php 

class StudentLogin_Action{

  

   function Login_Action(){
   	$this->EntityLogin->Login('student');
   }


}