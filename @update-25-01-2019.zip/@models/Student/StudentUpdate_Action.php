<?php 

class StudentUpdate_Action{

  
  function Update_Action($id){
  	global $data;
  	global $postData;

  	unset($postData['email']);
  	unset($postData['password']);
  	unset($postData['status']);

  	$this->EntityRead->SetWhere("id=$id");
  	$this->EntityUpdate->SetData($postData);
  	$this->EntityUpdate->DoUpdate('student');
  	$data['message'] = 'Student account updated';
  } 


}