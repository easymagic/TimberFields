<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/
class EntityUpdate{

   private $data = array();

   function DoUpdate($entity){

   	 global $db_where;
   	 global $db_sql;
     
     if (!empty($db_where)){
      DbUpdate($entity,$this->data);
     }

     // die($db_sql);
     
   }

   function SetData($data){
    $this->data = $data;
   }



}