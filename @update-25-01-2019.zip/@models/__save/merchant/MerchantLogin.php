<?php 
/**

@Inject(@models/entityv2/EntityLogin);

*/
class MerchantLogin{

  

  function Login(){
    global $post;

    $this->EntityLogin->SetData($post); 
    $this->EntityLogin->SetLoginFields('email','password');
    $this->EntityLogin->Login('merchant');
  }


}