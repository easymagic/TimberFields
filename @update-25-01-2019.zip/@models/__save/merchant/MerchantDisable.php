<?php 
/**

@Inject(@models/entityv2/EntityDisableField);

*/

class MerchantDisable{

   

   function Disable($id){

   	  $this->EntityRead->SetWhere("id=$id");
   	  $this->EntityDisableField->DisableField('merchant','status');

   }




}