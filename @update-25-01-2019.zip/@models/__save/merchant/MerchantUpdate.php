<?php 

/**

@Inject(@models/entityv2/EntityUpdate,
        @models/entityv2/EntityGenerateUID);

*/
class MerchantUpdate{

  


  function Update($id){
    global $postData;
    global $data;

    if (isset($postData['email'])){ //security measures
      unset($postData['email']);
    }
    if (isset($postData['password'])){ //security measures
     unset($postData['password']);
    }

  	$this->EntityUpdate->SetData($postData);
    $this->EntityRead->SetWhere("id=$id");
    $this->EntityUpdate->DoUpdate('merchant');

	  $this->EntityRead->SetWhere("id=$id");
    $this->EntityGenerateUID->GenerateUID('merchant','merch_secret',$id,11); //keep consistent.

  	$data['error'] = false;
  	$data['message'] = 'Account saved.';

  }



}