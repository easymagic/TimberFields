<?php 

/**

@Inject(@models/entityv2/EntityChangePassword);

*/

class AdminChangePassword{


   
   function ChangePassword($id){
    global $post;

    $this->EntityCheckPassword->SetData($post);
   	$this->EntityRead->SetWhere("id=$id");
   	$this->EntityChangePassword->ChangePassword('admin');

   }


}