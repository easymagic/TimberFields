<?php 

/**

@Inject(@models/entityv2/EntityCount);

*/

class AdminGetCount{

  

  function GetCount(){
    return $this->EntityCount->GetCount('admin');
  }



}