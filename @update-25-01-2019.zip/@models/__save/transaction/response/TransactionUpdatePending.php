<?php 
/**

@Inject(@models/entityv2/EntityUpdate);

*/


class TransactionUpdatePending{
  


  function UpdatePending($criteria){
     $this->EntityUpdate->Update('transaction',array('pstatus'=>'pending'),$criteria);
  }



}