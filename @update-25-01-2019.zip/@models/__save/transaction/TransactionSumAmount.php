<?php 
/**

@Inject(@models/entityv2/EntitySum);

*/


class TransactionSumAmount{
  


  function SumAmount(){
     return $this->EntitySum->GetSum('transaction','amount');
  }



}