<?php 
/**

@Inject(@models/entityv2/EntityReadOne);

*/

class TransactionGetOne{
  

  function GetOne($id){
  	$this->EntityRead->SetWhere("id=$id");
  	$this->EntityReadOne->ReadOne('transaction');
  }
   

}