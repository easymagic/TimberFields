<?php 

class TransactionFilterFailed{

  


   function FilterFailed(){//
    global $db_where;

   	global $transactionFilters;

   	$transactionFilters[] = "pstatus = 'failed'";
     
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") "; 

   }



}