<?php 

class TransactionFilterSettled{

  


   function FilterSettled(){//
    global $db_where;

   	global $transactionFilters;

   	$transactionFilters[] = "pstatus = 'settled'";
     
    $db_where = " where (" . implode(' and ', $transactionFilters) . ") ";

    // echo $db_where;

   }



}