<?php 
global $routeAction;
global $FE_PATH;
global $ClientSidebarMenu;
global $buffer;

$ClientSidebarMenu = '';

$FE_PATH = BASE_URL . 'FE2/';

CallAction('Client_Header');

$top = $buffer;
$buffer = '';

CallAction('Client_SideBarMenu');

$side = $buffer;
$buffer = '';

CallAction($routeAction . '_ClientContent');

$content = $buffer;
$buffer = '';

CallAction('Client_Custom');

$content_custom = $buffer;
$buffer = '';

// CallAction('Client_Destroy');

CallAction('Client_Footer');

$footer = $buffer;


$buffer = $top . $side . $content . $content_custom . $footer; //compose.



