<?php 

global $can_view_staff;
global $can_view_company;
global $can_view_company_staff;
global $can_view_dispatchers;
global $can_view_site_settings;
global $can_view_dispatch_requests;

?>    
    <aside class="main-sidebar">
        <section class="sidebar">
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION (ADMIN)</li>
                <li class="active">
                    <a href="<?php echo BASE_URL; ?>User/Dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>

                <?php 
                 if ($can_view_dispatch_requests){
                ?>
                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Transactions</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href=""><i class="fa fa-building-o"></i>Manage Dispatch Transactions</a></li>
                    </ul>
                </li>
                <?php 
                 }
                ?>



                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Accounts</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                     <?php 
                       if ($can_view_staff){
                     ?>
                      <li><a href="<?php echo BASE_URL; ?>Staff/GetList"><i class="fa fa-building-o"></i>Staffs</a></li>
                     <?php 
                      }

                      if ($can_view_company){
                     ?> 
                      <li><a href="<?php echo BASE_URL; ?>Company/GetList"><i class="fa fa-building-o"></i>Company</a></li>
                     <?php 
                      }

                      if ($can_view_company_staff){
                     ?> 
                      <li><a href="<?php echo BASE_URL; ?>CompanyStaff/GetList"><i class="fa fa-building-o"></i>Company-Staffs</a></li>
                     <?php 
                      }

                      if ($can_view_dispatchers){
                     ?> 
                      <li><a href="<?php echo BASE_URL; ?>Dispatcher/GetList"><i class="fa fa-building-o"></i>Dispatchers</a></li>
                     <?php 
                      }
                     ?> 
                      
<!--                       <li><a href="advert"><i class="fa fa-building-o"></i>Edit Profile</a></li>
 -->                      
                      <li><a href="<?php echo BASE_URL; ?>User/ChangeAccountPassword"><i class="fa fa-building-o"></i>Change Password</a></li>
                    </ul>
                </li>



                <?php 
                  if ($can_view_site_settings){
                ?>
                <li class="treeview">
                    <a href="#"><i class="fa  fa-tasks"></i> <span>Site Settings</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="<?php echo BASE_URL; ?>SiteSettings/GetOptions"><i class="fa fa-building-o"></i>Change Site-Settings</a></li>
                    </ul>
                </li>
                <?php 
                 }
                ?>



            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>
<!-- content start -->
