<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>

<h2 style="
    font-size: 40px;
    text-align: center;
    color: #5858d2;
    font-family: monospace;
    margin-top: 177px;
">
  InterPAY
</h2>
<h3 style="
    text-align: center;
    color: #777;
    font-family: cursive;
">
  Redirecting to payment gateway ....
</h3>

<script type="text/javascript">
  setTimeout(function(){
   // location.href = '<?php echo $transaction_data['paystack_auth_url']; ?>';
  },5000);
</script>
</body>
</html>