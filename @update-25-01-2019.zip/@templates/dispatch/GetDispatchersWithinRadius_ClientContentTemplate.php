<?php 
 global $charging_flat_rate;
?> 
<section class="main__middle__container">
  
<!--   <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
 -->

  <section class="recent-posts">
    <div class="container" style="
    width: 100%;
    padding: 0;
">

      <div class="row" style="padding-top: 0;padding: 0;margin: 0;/* width: 100%; */">
        <div class="col-xs-12" style="
    padding: 0;
"> 


   <div id="dvMap" style="height: 500px;">
   </div>

<!-- style="width: 100%; height: 500px;" -->
         
     <!-- [start] -->


<style type="text/css">
  .predictions-list-item:hover{
    background-color: #329832;
    color: #fff;
  }  


  @media(max-width: 768px){

     .handle-mobile{
      width: 80% !important;
     }

  }
</style>


<!-- rgba(0,0,0,0.2) -->
<div class="handle-mobile" style="position: absolute;top: 4%;margin-left: 10%;background-color: rgba(255,255,255,0.5);padding: 11px;width: 80%;">


<h2 style="margin-top: 0;" align="center">
  DISPATCHERS WITHIN YOUR REQUEST COVERAGE
</h2>

   
 <!-- dispatchers list -->
 <div class="col-xs-12">

 <div class="col-xs-12" style="background-color: #111;padding: 4px;">
   <b>
     From Pickup : <?php echo $pickup_address; ?>&nbsp;
   </b>

   <b class="pull-right">
     To DropOff : <?php echo $dropoff_address; ?>&nbsp;
   </b>

 </div>

 <?php 
 if (empty($user_data)){

  ?>
 
 <div class="col-xs-12" style="padding: 11px;background-color: #fff;" align="center">
    
    <h4>There are not dispatchers within your pickup area at this time yet.
       
       <small>
         <a href="<?php echo BASE_URL; ?>Dispatch/Request">Back.</a>
       </small>
    </h4>
   
 </div>
  <?php 

 }
 ?>

   <?php 
    // print_r($user_data);

    foreach ($user_data as $k=>$v){
  
  ?>
   
    <div class="col-xs-12" style="padding: 11px;background-color: #fff;">
      <div class="col-xs-12 col-md-1" style="margin: 0;padding: 0">
        <img src="<?php echo BASE_URL; ?>uploads/user/companylogo/<?php echo $v['company_data']['company_logo']; ?>" style="width: 64px;" />
      </div>
      <div class="col-xs-12 col-md-11" style="padding: 0;margin: 0;">
        
        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          <span style="color: #888;text-transform: uppercase;letter-spacing: 2px;">Company:</span> <?php echo $v['company_data']['company_name']; ?>
        </div>


        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          <span style="color: #888;text-transform: uppercase;letter-spacing: 2px;">Dispatch Rate:</span>
          <?php
            if ($v['company_data']['charging_pattern'] == 'platform'){

              echo '#' . number_format($charging_flat_rate);

            }else if ($v['company_data']['charging_pattern'] == 'company-defined-rate'){
              
              echo '#' . number_format($v['company_data']['charged_rate']);

            }else if ($v['company_data']['charging_pattern'] == 'rate-per-km'){

              echo '#' . number_format($v['company_data']['charged_rate'] * $dispatch_distance) . ' @ #' . number_format($v['company_data']['charged_rate']) . ' per KM';

            }else{
              echo 'N/A';
            }
          ?>
        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          <span style="color: #888;text-transform: uppercase;letter-spacing: 2px;">Dispatcher:</span> <?php echo $v['username'];  ?>
        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          <span style="color: #888;text-transform: uppercase;letter-spacing: 2px;">Distance:</span> <?php echo $dispatch_distance;  ?> KM
        </div>

        <div class="col-xs-12" style="color: #000;font-weight: bold;">
          <span style="color: #888;text-transform: uppercase;letter-spacing: 2px;">Charging Pattern:</span> <?php echo $v['company_data']['charging_pattern'];  ?>
        </div>

        <div class="col-xs-12" style="border-top: 1px solid #eee;padding-top: 9px;margin-top: 9px;">
<?php 
 if ($v['dispatch_availability'] == 'free'){
?>
<a href="<?php echo BASE_URL; ?>Dispatch/CreateDispatch/<?php echo $v['id']; ?>/<?php echo $v['company_data']['id']; ?>" class="pull-right btn btn-sm btn-default" style="color: #000;font-size: 14px;">Request Dispatcher</a>          

<?php
 }else{
?>
<a disabled href="#" class="pull-right btn btn-sm btn-default" style="color: #000;font-size: 14px;">Booked</a>          

<?php
 }
?>          
        </div>



      </div>
    </div>

  <?php   

    }
   ?>
 </div>  




</div>



        

        <!-- [end]   -->
          
        </div>
      </div>
    </div>
  </section>
</section>


<script type="text/javascript">
  
       window.onload = function () {

        EventBus.Notify('InitMap',{
          mapId:"dvMap"
        });

        // EventBus.Notify('AddMarkers',{
        //   markers:markers
        // });

        // EventBus.Notify('DrawPath',{
        //   markers:markers
        // });

        EventBus.Notify('ZoomMap',{
          zoom:10
        });


        // EventBus.Subscribe('MapGetDistance',function(result){
        //   console.log(result);
        // });

        // EventBus.Notify('MapComputeDistance',{
        //   locationA:{
        //     lat:markers[0]['lat'],
        //     lng:markers[0]['lng']
        //   },
        //   locationB:{
        //     lat:markers[1]['lat'],
        //     lng:markers[1]['lng']
        //   }
        // });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:markers[1]['lat'],
        //   lng:markers[1]['lng'],
        //   radius:11
        // });

          var markers_ = <?php echo json_encode($markers); ?>;

          EventBus.Notify('AddMarkers',{
            markers:markers_
          });
          EventBus.Notify('DrawPath',{
            markers:markers_
          });
  
          EventBus.Notify('ZoomArroundMarkers',{});    



        // EventBus.Notify('MapInitInputs',{
        //   pickup:'#pickup',
        //   dropoff:'#dropoff'
        // });


       };


</script>