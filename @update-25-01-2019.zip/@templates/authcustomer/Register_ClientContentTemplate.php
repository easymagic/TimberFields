<section class="main__middle__container">
  <div class="row no_padding no-margin nothing nice__title2 blog text-center">
    <div class="container">
      <h2>Customer</h2>
      <span class="sep"></span>
      <p><font color="#000000">Register</font></p>
    </div>
  </div>
  <section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;">
        <div class="col-md-8 col-md-offset-2"> 
          <h3>Customer Registration</h3>
          <hr>
          <!-- <p>Please enter your tracking ID below.</p> -->
          <p id="feedback"></p>
<form role="form" id="contact-form" name="contact-form" method="post"class="contact-form">
  
  <div class="form-group">
    
    <input type="text" class="form-control" name="data[first_name]" placeholder="First Name" value="<?php echo __('first_name'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="data[middle_name]" placeholder="Middle Name"value="<?php echo __('middle_name'); ?>" required="">
  </div>


  <div class="form-group">
    
<input type="text" class="form-control" name="data[surname]" placeholder="Surname" value="<?php echo __('surname'); ?>" required="">
  </div>


  <div class="form-group">
    <select class="form-control" name="data[gender]" required="">
      <option value="">--Select Gender--</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
  </div>


  <div class="form-group">
    
    <input type="email" class="form-control" name="data[email]" placeholder="E-mail" value="<?php echo __('email'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="data[phone]" placeholder="Phone" value="<?php echo __('phone'); ?>" required="">
  </div>


  <div class="form-group">
    
    <input type="password" class="form-control" name="password1" placeholder="Password" required="">
  </div>


  <div class="form-group">
    
    <input type="password" class="form-control" name="password2" placeholder="Confirm Password" required="">
  </div>


  <div class="form-group">
    
    <input type="text" class="form-control" name="data[address]" placeholder="Address" value="<?php echo __('address'); ?>" required/>
  </div>

  <input type="hidden" name="data[lat]" data-lat />
  <input type="hidden" name="data[lng]" data-lng />

  
  <input id="submit-button" type="submit" class="btn btn-sm btn-info" value="Submit">
</form>
          
          
        </div>
      </div>
    </div>
  </section>
</section>


