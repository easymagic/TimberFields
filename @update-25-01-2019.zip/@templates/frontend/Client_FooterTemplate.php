<?php 
global $FE_PATH;
?>
<div id="snackbar"></div>
<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <h3>About</h3>
        <p>Turbo Errands is a logistics solution provider driven to deliver a level of service that exceeds the expectations of our customers. <br />
          <br />
          If you have any questions about our products or services, please do not hesitate to contact us. We have friendly, knowledgeable representatives available seven days a week to assist you.</p>
      </div>
      <div class="col-md-3">
        <h3></h3>
        <p><a href="#">Our Vision</a><br />
          To be the most reliable and affordable logostics company in Nigeria.</p>
        <p><a href="#">Our Mission</a><br />
          To deliver packages safely and swiftly by using innovative and cost effective solutions, ensuring that the expectations of the clients are exceeded everytime.<br />
</p>
        <p><a href="#">Our Values</a><br />
          <a href="">T</a>imeliness and <a href="">E</a>xcellence.<br />
          
</p>

      </div>
      <div class="col-md-3">
        <h3>Count</h3>
        <p>12 Successful Deliveries
        <h3>Newsletter </h3>         
Subscribe to our mailing list for offers, news updates and more!
</p>
        <br />
        <form action="#" method="post" class="form-inline" role="form">
          <div class="form-group">
            <label class="sr-only" for="exampleInputEmail2">your email:</label>
            <input type="email" class="form-control form-control-lg" id="exampleInputEmail2" placeholder="your email:">
          </div>
          <button type="submit" class="btn btn-primary btn-md">subscribe</button>
        </form>
      </div>
      <div class="col-md-3">
        <h3>Social</h3>
        <div class="social__icons"> <a href="#" class="socialicon socialicon-twitter"></a> <a href="#" class="socialicon socialicon-facebook"></a> <a href="#" class="socialicon socialicon-google"></a> <a href="#" class="socialicon socialicon-mail"></a> </div>
      </div>
    </div>
    <hr>
    <p class="text-center">&copy; Copyright Turbo Errands. All Rights Reserved.</p>
  </div>
</footer>


<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo $FE_PATH; ?>js/bootstrap.min.js"></script> 
<script type="text/javascript">

$('.carousel').carousel({
  interval: 3500, // in milliseconds
  pause: 'none' // set to 'true' to pause slider on mouse hover
})

</script>
<script src="<?php echo $FE_PATH; ?>js/jquery.mixitup.min.js"></script> 
<script src="<?php echo $FE_PATH; ?>js/jquery.magnific-popup.js"></script> 
<script type="text/javascript">
    $(document).ready(function () {
        // Start work gallery
        $('#Grid').mixitup();
        });
        $('.gallery').each(function() { // the containers for all your galleries
            $(this).magnificPopup({
                delegate: 'a', // the selector for gallery item
                type: 'image',
                gallery: {
                  enabled:true
                }
            });
        });
	</script>

  <script type="text/javascript">

<?php 
 if (isset($message) && !empty($message)){

  if (!isset($error) || !$error){
     $cls = 'show-success';     
  }else{
     $cls = 'show-error';
  }

?>

var x = document.getElementById("snackbar");
    x.className = "<?php echo $cls; ?>";
    x.innerHTML = '<?php echo $message; ?>';
    setTimeout(function(){ x.className = x.className.replace("<?php echo $cls; ?>", ""); }, 3000);


<?php 

 }
?>    
    


function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition,function(){},{maximumAge:60000, timeout:5000, enableHighAccuracy:true});
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  
  console.log(position);
  
  jQuery('[data-lat]').val(position.coords.latitude);
  jQuery('[data-lng]').val(position.coords.longitude);
  // x.innerHTML = "Latitude: " + position.coords.latitude + 
  // "<br>Longitude: " + position.coords.longitude; 


        EventBus.Notify('AddMarkers',{
          markers:[{
            lat:position.coords.latitude,
            lng:position.coords.longitude,
            description:'You'
          }]
        });


        // EventBus.Notify('MapDrawRadiusRange',{
        //   lat:position.coords.latitude,
        //   lng:position.coords.longitude,
        //   radius:11
        // });


}

getLocation();

  </script>


</body>
</html>