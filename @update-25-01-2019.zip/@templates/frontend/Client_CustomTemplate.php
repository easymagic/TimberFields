<section class="recent-posts">
    <div class="container">

      <div class="row" style="padding-top: 0;padding-left: 11px;padding-top: 22px;">

        <div class="col-md-12" style="
    padding: 0;
"> 

<div class="col-md-3 col-xs-12" style="
    padding: 0;
">
<?php 
 echo $CustomClientSideBar;
?>
</div>

<div class="col-md-7 col-xs-12">
<?php 
 echo $CustomClientContent;
?>
</div>

          
          
        </div>
      </div>
    </div>
  </section>