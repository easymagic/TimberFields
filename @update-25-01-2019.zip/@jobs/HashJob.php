<?php 

/**

@Inject(app-x/core/EmailQueue);

*/

$hashID = 0;
$hashedID = '';


class HashJob{

   
   function PostJob(){
    global $hashID;
    global $hashedID;

    if (!empty($hashID)){
       $hashedID = substr(md5($hashID),-7);
       $hashID = 0;
    }
   }

}
