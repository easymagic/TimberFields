<?php 

/**

@Inject(app-x/core/EmailQueue);

*/

$cart = array();
$addCart = '';
$removeCart = '';
$cartTotalQty = 0;
$cartTotalPrice = 0;


class CartJob{

   
   function PostJob(){
    global $cart;
    global $addCart;
    global $removeCart;
    global $session;
    global $data;
    global $cartTotalQty;
    global $cartTotalPrice;


    if (!isset($session['cart_list'])){
      $session['cart_list'] = array();
    }

    $cart = $session['cart_list'];

    if (!empty($addCart) && isset($addCart['id'])){

       if (isset($cart[$addCart['id']])){
         ++$cart[$addCart['id']]['qty'];
         $data['message'] = 'Cart Updated..';
       }else{
         $addCart['qty'] = 1;
         $cart[$addCart['id']] = $addCart; 
         $data['message'] = 'New Item Added To Cart.';
       }

       $addCart = ''; //reset
         
    }
    
    // echo $removeCart;
    if (!empty($removeCart) && is_numeric($removeCart) && $removeCart*1 > 0){
      // echo 'rmv';
       $removeCart = $removeCart * 1;
       if (isset($cart[$removeCart])){
         unset($cart[$removeCart]);
         $data['message'] = 'Item Removed From Cart.';
       }else{
         $data['message'] = 'Item Not Found In Cart!';
       }

       $removeCart = ''; //reset
    }

    $session['cart_list'] = $cart; //update session.

    //total price & qty
    foreach ($cart as $ct){

      if (isset($ct['price'])){
        $cartTotalPrice+=$ct['price']*$ct['qty'];
      }
      if (isset($ct['qty'])){
        $cartTotalQty+=$ct['qty'];
      }
      
    }
   }

}
