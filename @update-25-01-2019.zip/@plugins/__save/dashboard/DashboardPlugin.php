<?php 

/**

@Inject(@models/admin/AdminGetCount,
        @models/admin/AdminGetList,
        @models/merchant/MerchantGetCount,
        @models/merchant/MerchantGetList,
        @models/transaction/TransactionGetCount,
        @models/transaction/TransactionSumAmount,
        @models/transaction/filters/TransactionFilterSuccess);

*/


class DashboardPlugin{

  
  function Init(){
    // global $transactionFilters;
    // $transactionFilters = array();    
  }

  ////dashboard///////
  function Dashboard_AdminContent(){

     global $data;

     // CallAction('Init_Admin');
     $data['adminCount'] = $this->AdminGetCount->GetCount();
     
     CallAction('Init_Merchant');
     $data['merchantCount'] = $this->MerchantGetCount->GetCount();
     
     //filter for successful transactions.
     CallAction('Init_Transaction');
     $this->TransactionFilterSuccess->FilterSuccess();
     $data['transactionCount'] = $this->TransactionGetCount->GetCount();
     
     CallAction('Init_Transaction');
     $this->TransactionFilterSuccess->FilterSuccess();
     $data['transactionSum'] = $this->TransactionSumAmount->SumAmount();
    
  }


}