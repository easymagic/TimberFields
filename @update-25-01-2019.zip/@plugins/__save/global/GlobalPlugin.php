<?php 
/**
@Inject(@models/User/UserGetDispatchWithinRadius);
*/


class GlobalPlugin{



     function GetDispatchWithinRadius($lat='6.503638899999999',$lng='3.601250299999947',$radius='11.74'){
     	global $contentType;
     	global $data;

     	$contentType = 'json';

     	$this->UserGetDispatchWithinRadius->GetDispatchWithinRadius($lat,$lng,$radius);

     }


}