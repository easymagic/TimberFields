<?php 


class CheckAdminSessionLoggedPlugin{

  function Init(){
    global $session;
    global $data;
    global $logged;
    global $session_type;
    global $adminID;

    $logged = false;
    $session_type = 'admin';
    
    $data['role'] = '';
    if (isset($session['admin_session'])){
       $data['role'] = $session['admin_session']['role'];
       $logged = true;
       $data['session_type'] = $session_type;
       $adminID = $session['admin_session']['id'];
    }
   
  }

  


  function Page_Init(){
    // echo 'Called';
    global $logged;
    global $redirect;

    if (!$logged){
      $redirect = 'Accounts';
    }
  }


    function Page_Destroy(){
      global $session;
      global $data;

      unset($session['data']);
      unset($data['message']);
      unset($data['error']);
    }



 

}