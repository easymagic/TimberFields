<?php 
// require_once "Mail.php";


  class EmailQueue{

   private $message = '';
   private $subject = '';
   private $to = '';
   private $from = ''; 
     
  function Send(){
     // echo 'Mail test sent';
     // return;
   
     $to = $this->to; 
     $subject = $this->subject; 
     $msg = $this->message; 
     $from = $this->from; 

      if (mail(
        $to, 
        $subject, 
        $msg, 
        "From: " . $from . "\n" . 
        "MIME-Version: 1.0\n" .
        "Content-type: text/html; charset=iso-8859-1"
      )){
        //echo 'Sent ..';
      }else{
        //echo 'Not sent ...';  
      }   


  }


  // function Send(){


  //     $from = "Info <info@turboerrands.com>";

  //     $to = $this->to;

  //     $subject = $this->subject;

  //     $body = $this->message;

  //     $host = "turboerrands.com";

  //     $username = "info@turboerrands.com";

  //     $password = "qkqgx@?_}ZpO";



  //     $headers = array ('From' => $from,

  //       'To' => $to,

  //       'Subject' => $subject,
  //       'Content-type'=>'text/html');

  //     $smtp = @Mail::factory('smtp',

  //       array ('host' => $host,

  //         'auth' => true,


  //         'username' => $username,

  //         'password' => $password));



  //     $mail = @$smtp->send($to, $headers, $body);



  //     if (@PEAR::isError($mail)) {

  //       echo("<p>" . $mail->getMessage() . "</p>");


  //      } else {

  //       // echo("<p>Message successfully sent!</p>");
  //      }
  // }



  function SetSubject($sub){
    $this->subject = $sub;
  }

  function SetMessage($msg){
    $this->message = $msg;
  }

  function SetTo($to){
    $this->to = $to;
  }

  function SetFrom($from){
    $this->from = $from;
  }


  }
 
 

