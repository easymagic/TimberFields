<?php 

class RequestResponse{
  
  private $request = array();
  private $response = array();

  function GetResponse(){
    return $this->response;
  }

  function GetRequest(){
   return $this->request;
  }

  function SetRequest($request){
   $this->request = $request;
  }

  function AddRequest($k,$v){
   $this->request[$k] = $v;
  }

  function SetResponse($k,$v){
    $this->response[$k] = $v;
  }

  function ClearResponse(){
   $this->response = array();
  }

  function ClearRequest(){
   $this->request = array(); 
  }


}
