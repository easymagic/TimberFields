<?php 
class RedirectThread{
    
    

	function Run(){
      $this->LoadVars(); 
	}



	function LoadVars(){
	    global $redirect;

	    if (!empty($redirect)){
	      header("Location: " . BASE_URL . $redirect);
	      $redirect = '';
	      exit();
	    }    

	}

  
  


}