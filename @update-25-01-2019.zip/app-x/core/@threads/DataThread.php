<?php 
class DataThread{
    
    private $called = false;
    

	function Run(){

	 if (!$this->called){
       $this->called = true;
       $this->LoadVars(); 
	 }

	}


	function LoadVars(){

	 global $data;
	 $data = array();

	}


}